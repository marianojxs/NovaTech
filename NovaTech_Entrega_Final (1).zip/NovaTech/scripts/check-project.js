const fs = require("fs");
const path = require("path");
const { execFileSync } = require("child_process");
const ejs = require("ejs");

const root = path.resolve(__dirname, "..");
const ignore = new Set(["node_modules"]);
let checkedJs = 0;
let checkedEjs = 0;
let loadedModules = 0;

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (ignore.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else files.push(full);
  }
  return files;
}

const requiredPaths = [
  "app.js",
  "models",
  "controllers",
  "routes",
  "views",
  "public/css/estilos.css",
  ".env.example",
  "README.md",
];

for (const relative of requiredPaths) {
  const full = path.join(root, relative);
  if (!fs.existsSync(full)) {
    throw new Error(`Falta un recurso obligatorio del proyecto: ${relative}`);
  }
}

const files = walk(root);
for (const file of files.filter((f) => f.endsWith(".js"))) {
  execFileSync(process.execPath, ["--check", file], { stdio: "pipe" });
  checkedJs += 1;
}

for (const file of files.filter((f) => f.endsWith(".ejs"))) {
  const source = fs.readFileSync(file, "utf8");
  ejs.compile(source, { filename: file });
  checkedEjs += 1;
}

// Carga controladores, modelos y rutas para detectar imports inexistentes,
// exports mal nombrados y handlers no definidos antes de ejecutar el sistema.
for (const dir of ["models", "controllers", "routes", "services"]) {
  const dirPath = path.join(root, dir);
  if (!fs.existsSync(dirPath)) continue;
  for (const file of fs.readdirSync(dirPath).filter((name) => name.endsWith(".js"))) {
    require(path.join(dirPath, file));
    loadedModules += 1;
  }
}

console.log(`✓ ${checkedJs} archivos JavaScript sin errores de sintaxis`);
console.log(`✓ ${checkedEjs} vistas EJS compiladas correctamente`);
console.log(`✓ ${loadedModules} módulos cargados sin imports/exports rotos`);
console.log("✓ Estructura mínima del proyecto verificada");
console.log("✓ Revisión estática completada");
