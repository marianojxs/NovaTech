const mongoose = require("mongoose");
require("dotenv").config();

const Categoria = require("../models/Categoria");
const Cliente = require("../models/Cliente");
const Proveedor = require("../models/Proveedor");
const MetodoPago = require("../models/MetodoPago");
const Sucursal = require("../models/Sucursal");
const Usuario = require("../models/Usuario");
const Producto = require("../models/Producto");
const Compra = require("../models/Compra");
const Venta = require("../models/Venta");
const DetalleVenta = require("../models/DetalleVenta");
const Devolucion = require("../models/Devolucion");
const { aplicarMovimiento } = require("../services/inventoryService");

const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/NovaTechDB";

async function upsert(Model, filtro, datos) {
  return Model.findOneAndUpdate(
    filtro,
    { $setOnInsert: datos },
    { upsert: true, new: true, runValidators: true }
  );
}

async function cargarCatalogos() {
  const categorias = {};
  for (const item of [
    { nombre: "Computadoras", descripcion: "Equipos portátiles y de escritorio", estado: "Activa" },
    { nombre: "Accesorios", descripcion: "Periféricos y accesorios tecnológicos", estado: "Activa" },
    { nombre: "Componentes", descripcion: "Componentes internos y almacenamiento", estado: "Activa" },
  ]) {
    categorias[item.nombre] = await upsert(Categoria, { nombre: item.nombre }, item);
  }

  const metodos = {};
  for (const nombre of ["Efectivo", "Tarjeta de crédito", "Tarjeta de débito", "SINPE Móvil", "Transferencia"]) {
    metodos[nombre] = await upsert(MetodoPago, { nombre }, { nombre });
  }

  const sucursales = {};
  sucursales.Cartago = await upsert(
    Sucursal,
    { codigo: "CT-01" },
    { codigo: "CT-01", nombre: "Cartago", direccion: "Cartago, Costa Rica" }
  );
  sucursales["San José"] = await upsert(
    Sucursal,
    { codigo: "SJ-01" },
    { codigo: "SJ-01", nombre: "San José", direccion: "San José, Costa Rica" }
  );

  const usuarios = {};
  usuarios.admin = await upsert(Usuario, { usuario: "admin" }, { usuario: "admin", nombre: "Administrador NovaTech", rol: "Administrador" });
  usuarios.ventas = await upsert(Usuario, { usuario: "ventas01" }, { usuario: "ventas01", nombre: "Ejecutivo de Ventas", rol: "Ventas" });
  usuarios.compras = await upsert(Usuario, { usuario: "compras01" }, { usuario: "compras01", nombre: "Encargado de Compras", rol: "Compras" });

  const clientes = {};
  clientes.ana = await upsert(Cliente, { identificacion: "1-1111-1111" }, {
    identificacion: "1-1111-1111",
    nombre: "Ana Rodríguez Mora",
    telefono: "8888-8888",
    correo: "ana.rodriguez@example.com",
    direccion: "Cartago, Costa Rica",
    estado: "Activo",
  });
  clientes.carlos = await upsert(Cliente, { identificacion: "2-2222-2222" }, {
    identificacion: "2-2222-2222",
    nombre: "Carlos Vargas Pérez",
    telefono: "8777-7777",
    correo: "carlos.vargas@example.com",
    direccion: "San José, Costa Rica",
    estado: "Activo",
  });

  const proveedores = {};
  proveedores.global = await upsert(Proveedor, { cedulaJuridica: "3-101-100001" }, {
    cedulaJuridica: "3-101-100001",
    empresa: "Tecnología Global S.A.",
    contacto: "Laura Jiménez",
    telefono: "2222-1000",
    correo: "ventas@tecnologiaglobal.example.com",
    direccion: "San José, Costa Rica",
    estado: "Activo",
  });
  proveedores.digital = await upsert(Proveedor, { cedulaJuridica: "3-101-100002" }, {
    cedulaJuridica: "3-101-100002",
    empresa: "Distribuidora Digital S.A.",
    contacto: "Marco Solano",
    telefono: "2222-2000",
    correo: "info@digital.example.com",
    direccion: "Heredia, Costa Rica",
    estado: "Activo",
  });

  return { categorias, metodos, sucursales, usuarios, clientes, proveedores };
}

async function cargarProductos(categorias) {
  const productos = {};
  const demo = [
    { key: "laptop", codigo: "LAP-001", nombre: "Laptop NovaBook 14", descripcion: "Laptop de uso empresarial y académico", categoria: "Computadoras", marca: "Nova", precio: 350000, stockInicial: 12 },
    { key: "teclado", codigo: "ACC-001", nombre: "Teclado inalámbrico", descripcion: "Teclado inalámbrico compacto", categoria: "Accesorios", marca: "KeyPro", precio: 18000, stockInicial: 25 },
    { key: "mouse", codigo: "ACC-002", nombre: "Mouse inalámbrico", descripcion: "Mouse óptico inalámbrico", categoria: "Accesorios", marca: "ClickPro", precio: 8500, stockInicial: 30 },
    { key: "ssd", codigo: "CMP-001", nombre: "SSD NVMe 1 TB", descripcion: "Unidad de estado sólido NVMe de alto rendimiento", categoria: "Componentes", marca: "DataCore", precio: 42000, stockInicial: 4 },
  ];

  for (const item of demo) {
    let producto = await Producto.findOne({ codigo: item.codigo });
    if (!producto) {
      const categoria = categorias[item.categoria];
      producto = await Producto.create({
        codigo: item.codigo,
        nombre: item.nombre,
        descripcion: item.descripcion,
        categoriaId: categoria._id,
        categoria: categoria.nombre,
        marca: item.marca,
        precio: item.precio,
        stock: 0,
        estado: "Agotado",
      });

      await aplicarMovimiento({
        productoId: producto._id,
        tipo: "Entrada",
        cantidad: item.stockInicial,
        origen: "Ajuste",
        referencia: "Stock inicial - datos demo",
        documentoId: producto._id,
      });
      producto = await Producto.findById(producto._id);
    }
    productos[item.key] = producto;
  }

  return productos;
}

async function cargarTransacciones({ clientes, proveedores, metodos, sucursales, usuarios }, productos) {
  let compra = await Compra.findOne({ numeroCompra: "C-DEMO-001" });
  if (!compra) {
    compra = await Compra.create({
      numeroCompra: "C-DEMO-001",
      fecha: new Date("2026-08-01"),
      proveedorId: proveedores.global._id,
      proveedor: proveedores.global.empresa,
      productoId: productos.laptop._id,
      codigoProducto: productos.laptop.codigo,
      nombreProducto: productos.laptop.nombre,
      cantidad: 5,
      precioUnitario: 290000,
      total: 1450000,
      estado: "Recibida",
      sucursalId: sucursales.Cartago._id,
      sucursal: sucursales.Cartago.nombre,
      usuarioId: usuarios.compras._id,
      registradoPor: usuarios.compras.nombre,
    });

    await aplicarMovimiento({
      productoId: productos.laptop._id,
      tipo: "Entrada",
      cantidad: compra.cantidad,
      fecha: compra.fecha,
      origen: "Compra",
      referencia: compra.numeroCompra,
      documentoId: compra._id,
    });
  }

  let venta = await Venta.findOne({ factura: "V-DEMO-001" });
  if (!venta) {
    const laptop = await Producto.findById(productos.laptop._id);
    const cantidad = 2;
    if (laptop.stock >= cantidad) {
      venta = await Venta.create({
        factura: "V-DEMO-001",
        clienteId: clientes.ana._id,
        cliente: clientes.ana.nombre,
        fecha: new Date("2026-08-03"),
        productoId: laptop._id,
        codigoProducto: laptop.codigo,
        nombreProducto: laptop.nombre,
        cantidad,
        precioUnitario: laptop.precio,
        total: cantidad * laptop.precio,
        metodoPagoId: metodos["Tarjeta de crédito"]._id,
        metodoPago: metodos["Tarjeta de crédito"].nombre,
        sucursalId: sucursales.Cartago._id,
        sucursal: sucursales.Cartago.nombre,
        usuarioId: usuarios.ventas._id,
        registradoPor: usuarios.ventas.nombre,
        estado: "Facturada",
      });

      await aplicarMovimiento({
        productoId: laptop._id,
        tipo: "Salida",
        cantidad: venta.cantidad,
        fecha: venta.fecha,
        origen: "Venta",
        referencia: venta.factura,
        documentoId: venta._id,
      });

      await DetalleVenta.create({
        ventaId: venta._id,
        clienteId: venta.clienteId,
        productoId: venta.productoId,
        numeroVenta: venta.factura,
        fechaVenta: venta.fecha,
        cliente: venta.cliente,
        codigoProducto: venta.codigoProducto,
        nombreProducto: venta.nombreProducto,
        cantidad: venta.cantidad,
        precioUnitario: venta.precioUnitario,
        subtotal: venta.total,
        estado: "Facturada",
      });
    }
  }

  if (venta) {
    const devolucionExistente = await Devolucion.findOne({ numero: "D-DEMO-001" });
    if (!devolucionExistente) {
      const devolucion = await Devolucion.create({
        numero: "D-DEMO-001",
        ventaId: venta._id,
        factura: venta.factura,
        clienteId: venta.clienteId,
        cliente: venta.cliente,
        productoId: venta.productoId,
        codigoProducto: venta.codigoProducto,
        producto: venta.nombreProducto,
        cantidad: 1,
        motivo: "Producto devuelto para demostración del flujo integrado.",
        fecha: new Date("2026-08-05"),
      });

      await aplicarMovimiento({
        productoId: venta.productoId,
        tipo: "Entrada",
        cantidad: devolucion.cantidad,
        fecha: devolucion.fecha,
        origen: "Devolución",
        referencia: devolucion.numero,
        documentoId: devolucion._id,
      });
    }
  }
}

async function main() {
  await mongoose.connect(uri);
  const catalogos = await cargarCatalogos();
  const productos = await cargarProductos(catalogos.categorias);
  await cargarTransacciones(catalogos, productos);

  console.log("✓ Datos de demostración listos en NovaTechDB");
  console.log("✓ Catálogos, productos y flujos integrados disponibles para la presentación");
  console.log("✓ La carga es incremental y no elimina información existente");
  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error("Error al cargar datos demo:", error);
  await mongoose.disconnect().catch(() => {});
  process.exit(1);
});
