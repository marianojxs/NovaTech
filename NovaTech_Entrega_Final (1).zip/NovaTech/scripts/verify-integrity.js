const mongoose = require("mongoose");
require("dotenv").config();

const Producto = require("../models/Producto");
const Inventario = require("../models/Inventario");
const Venta = require("../models/Venta");
const DetalleVenta = require("../models/DetalleVenta");
const Compra = require("../models/Compra");
const Devolucion = require("../models/Devolucion");

const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/NovaTechDB";
const problemas = [];
const avisos = [];

const registrarProblema = (mensaje) => problemas.push(mensaje);
const registrarAviso = (mensaje) => avisos.push(mensaje);

async function verificarStock() {
  const productos = await Producto.find();
  for (const producto of productos) {
    const movimientos = await Inventario.find({ productoId: producto._id });
    const saldo = movimientos.reduce(
      (total, movimiento) => total + (movimiento.tipo === "Entrada" ? movimiento.cantidad : -movimiento.cantidad),
      0
    );
    if (Number(saldo) !== Number(producto.stock)) {
      registrarProblema(
        `Stock inconsistente en ${producto.codigo}: producto=${producto.stock}, movimientos=${saldo}.`
      );
    }
  }
}

async function verificarVentas() {
  const ventas = await Venta.find({ estado: "Facturada" });
  for (const venta of ventas) {
    const detalle = await DetalleVenta.findOne({
      $or: [{ ventaId: venta._id }, { numeroVenta: venta.factura }],
    });
    const movimiento = await Inventario.findOne({
      documentoId: venta._id,
      origen: "Venta",
      tipo: "Salida",
    });

    if (!detalle) registrarProblema(`La venta ${venta.factura} no tiene detalle asociado.`);
    if (!movimiento) registrarProblema(`La venta ${venta.factura} no tiene salida de inventario.`);

    if (detalle) {
      if (Number(detalle.subtotal) !== Number(venta.total)) {
        registrarProblema(`El subtotal del detalle no coincide con la venta ${venta.factura}.`);
      }
      if (Number(detalle.cantidad) !== Number(venta.cantidad)) {
        registrarProblema(`La cantidad del detalle no coincide con la venta ${venta.factura}.`);
      }
    }

    if (!venta.clienteId || !venta.productoId || !venta.metodoPagoId) {
      registrarAviso(`La venta ${venta.factura} pertenece a una versión anterior y no contiene todas las referencias ObjectId.`);
    }
  }
}

async function verificarCompras() {
  const compras = await Compra.find({ estado: "Recibida" });
  for (const compra of compras) {
    const movimiento = await Inventario.findOne({
      documentoId: compra._id,
      origen: "Compra",
      tipo: "Entrada",
    });
    if (!movimiento) registrarProblema(`La compra recibida ${compra.numeroCompra} no tiene entrada de inventario.`);
  }
}

async function verificarDevoluciones() {
  const devoluciones = await Devolucion.find();
  for (const devolucion of devoluciones) {
    const movimiento = await Inventario.findOne({
      documentoId: devolucion._id,
      origen: "Devolución",
      tipo: "Entrada",
    });
    if (!movimiento) registrarProblema(`La devolución ${devolucion.numero} no tiene entrada de inventario.`);
  }
}

async function main() {
  await mongoose.connect(uri);
  console.log("NovaTech · verificación de integridad");
  console.log("-----------------------------------");

  await verificarStock();
  await verificarVentas();
  await verificarCompras();
  await verificarDevoluciones();

  const [productos, ventas, compras, devoluciones, movimientos] = await Promise.all([
    Producto.countDocuments(),
    Venta.countDocuments(),
    Compra.countDocuments(),
    Devolucion.countDocuments(),
    Inventario.countDocuments(),
  ]);

  console.log(`✓ Productos revisados: ${productos}`);
  console.log(`✓ Ventas revisadas: ${ventas}`);
  console.log(`✓ Compras revisadas: ${compras}`);
  console.log(`✓ Devoluciones revisadas: ${devoluciones}`);
  console.log(`✓ Movimientos revisados: ${movimientos}`);

  if (avisos.length) {
    console.log("\nAvisos:");
    avisos.forEach((mensaje) => console.log(`  • ${mensaje}`));
  }

  if (problemas.length) {
    console.log("\nInconsistencias detectadas:");
    problemas.forEach((mensaje) => console.log(`  ✗ ${mensaje}`));
    console.log("\nLa verificación terminó con observaciones. Revise los registros anteriores a la integración automática.");
    if (process.env.VERIFY_STRICT === "true") process.exitCode = 1;
  } else {
    console.log("\n✓ Integridad verificada: stock, ventas, detalles y movimientos son consistentes.");
  }

  await mongoose.disconnect();
}

main().catch(async (error) => {
  console.error("Error al verificar integridad:", error.message);
  await mongoose.disconnect().catch(() => {});
  process.exit(1);
});
