const express = require("express");
const mongoose = require("mongoose");
const methodOverride = require("method-override");
const path = require("path");
require("dotenv").config();

const { inicio } = require("./controllers/homeController");

const clienteRoutes = require("./routes/clienteRoutes");
const proveedorRoutes = require("./routes/proveedorRoutes");
const sucursalRoutes = require("./routes/sucursalRoutes");
const usuarioRoutes = require("./routes/usuarioRoutes");
const ventaRoutes = require("./routes/ventaRoutes");
const categoriaRoutes = require("./routes/categoriaRoutes");
const compraRoutes = require("./routes/compraRoutes");
const detalleVentaRoutes = require("./routes/detalleVentaRoutes");
const devolucionRoutes = require("./routes/devolucionRoutes");
const inventarioRoutes = require("./routes/inventarioRoutes");
const metodoPagoRoutes = require("./routes/metodoPagoRoutes");
const productoRoutes = require("./routes/productoRoutes");

const apiClienteRoutes = require("./routes/apiClienteRoutes");
const apiCategoriaRoutes = require("./routes/apiCategoriaRoutes");
const apiCompraRoutes = require("./routes/apiCompraRoutes");
const apiDetalleVentaRoutes = require("./routes/apiDetalleVentaRoutes");
const apiInventarioRoutes = require("./routes/apiInventarioRoutes");
const apiMetodoPagoRoutes = require("./routes/apiMetodoPagoRoutes");
const apiProductoRoutes = require("./routes/apiProductoRoutes");
const apiVentaRoutes = require("./routes/apiVentaRoutes");

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride("_method"));

// Estado básico de la aplicación para pruebas técnicas
app.get("/api/status", (req, res) => {
  res.status(200).json({
    aplicacion: "NovaTech Solutions",
    estado: "operativo",
    baseDatos: mongoose.connection.readyState === 1 ? "conectada" : "desconectada",
    timestamp: new Date().toISOString(),
  });
});

// Panel principal
app.get("/", inicio);

// Módulos web
app.use("/clientes", clienteRoutes);
app.use("/proveedores", proveedorRoutes);
app.use("/sucursales", sucursalRoutes);
app.use("/usuarios", usuarioRoutes);
app.use("/ventas", ventaRoutes);
app.use("/categorias", categoriaRoutes);
app.use("/compras", compraRoutes);
app.use("/detalle-ventas", detalleVentaRoutes);
app.use("/devoluciones", devolucionRoutes);
app.use("/inventario", inventarioRoutes);
app.use("/metodos-pago", metodoPagoRoutes);
app.use("/productos", productoRoutes);

// Alias de compatibilidad con versiones anteriores del proyecto.
app.use("/detalleVentas", detalleVentaRoutes);
app.use("/metodosPago", metodoPagoRoutes);

// API para pruebas con Postman
app.use("/api/clientes", apiClienteRoutes);
app.use("/api/categorias", apiCategoriaRoutes);
app.use("/api/compras", apiCompraRoutes);
app.use("/api/detalle-ventas", apiDetalleVentaRoutes);
app.use("/api/inventario", apiInventarioRoutes);
app.use("/api/metodos-pago", apiMetodoPagoRoutes);
app.use("/api/productos", apiProductoRoutes);
app.use("/api/ventas", apiVentaRoutes);

app.use((req, res) => {
  res.status(404).render("errors/404", { url: req.originalUrl });
});

const conectarBaseDatos = async () => {
  try {
    const uri = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/NovaTechDB";
    await mongoose.connect(uri);

    const puerto = process.env.PORT || 3000;
    app.listen(puerto, () => {
      console.log("✓ Conexión exitosa con MongoDB");
      console.log(`✓ NovaTech disponible en http://localhost:${puerto}`);
    });
  } catch (error) {
    console.error("Error al conectar con MongoDB:", error.message);
    process.exit(1);
  }
};

conectarBaseDatos();
