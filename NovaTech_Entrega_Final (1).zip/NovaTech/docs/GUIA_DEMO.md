# Guía de demostración del sistema

## Preparación

```bash
npm install
npm run check
npm run seed
npm run verify
npm run dev
```

Abrir `http://localhost:3000`.

## Recorrido recomendado

1. **Dashboard**
   - Mostrar métricas, ventas recientes y alertas de stock.
   - Explicar que la información se consulta directamente desde MongoDB.

2. **Productos**
   - Mostrar categoría, precio, stock y estado.
   - Realizar una búsqueda por código o nombre.

3. **Compras**
   - Registrar una compra como `Recibida`.
   - Verificar que aumente el stock del producto.
   - Abrir Inventario y mostrar la entrada generada automáticamente.

4. **Ventas**
   - Seleccionar cliente, producto y método de pago desde catálogos existentes.
   - Mostrar el precio y total calculados automáticamente.
   - Guardar la venta.

5. **Detalle de ventas**
   - Mostrar que el detalle se creó automáticamente sin volver a digitar la venta.

6. **Inventario**
   - Mostrar la salida generada por la venta y el nuevo stock.

7. **Devoluciones**
   - Crear una devolución desde una venta existente.
   - Mostrar la entrada automática en inventario.

8. **MongoDB Compass**
   - Mostrar las colecciones y uno de los documentos creados.
   - Enseñar la pestaña de índices de una colección.

9. **Postman**
   - Ejecutar un GET de `/api/productos` o `/api/ventas`.
   - Ejecutar un POST sencillo y mostrar el código HTTP de respuesta.

## Puntos técnicos para explicar

- Arquitectura MVC simplificada.
- MongoDB + Mongoose.
- Referencias ObjectId y snapshots.
- Índices únicos y de texto.
- Validación del lado servidor.
- Reglas de stock centralizadas en un servicio.
- Rollback compensatorio para operaciones que afectan varias colecciones.
