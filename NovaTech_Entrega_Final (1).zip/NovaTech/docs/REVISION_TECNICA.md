# Revisión técnica de NovaTech Solutions

## Verificaciones realizadas

- Revisión de sintaxis de archivos JavaScript.
- Compilación de todas las vistas EJS.
- Carga de modelos, controladores, rutas y servicios para detectar imports o exports inválidos.
- Revisión de los 12 esquemas Mongoose.
- Revisión de rutas web y API declaradas en `app.js`.
- Validación del flujo `Compra → Inventario`.
- Validación del flujo `Venta → DetalleVenta → Inventario`.
- Validación del flujo `Devolución → Inventario`.
- Protección contra stock negativo.
- Rollback compensatorio en operaciones integradas.
- Protección de eliminaciones que dejarían referencias huérfanas.
- Sincronización de categoría y producto mediante referencia y snapshot.
- Índices únicos y de texto para búsquedas relevantes.
- Homogeneización visual mediante Bootstrap y estilos propios.
- Script de carga de datos de demostración.
- Script de verificación de integridad entre colecciones.
- Colección de Postman para pruebas API.

## Validaciones de integridad

- Una categoría utilizada por productos no se elimina directamente.
- Un cliente con ventas o devoluciones asociadas no se elimina directamente.
- Un proveedor con compras asociadas no se elimina directamente.
- Un método de pago utilizado por ventas no se elimina directamente.
- Una sucursal o usuario con operaciones relacionadas no se elimina directamente.
- Un producto con historial comercial o inventario no se elimina directamente.
- Una venta con devoluciones no se modifica ni elimina sin resolver primero esas devoluciones.
- Una devolución no puede superar la cantidad vendida.
- Una venta no puede registrar una cantidad superior al stock disponible.

## Comandos de revisión

```bash
npm install
npm run check
npm run seed
npm run verify
npm run dev
```

La prueba funcional final debe realizarse con MongoDB activo en el equipo donde se ejecutará la demostración.
