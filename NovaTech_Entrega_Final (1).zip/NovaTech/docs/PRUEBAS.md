# Plan de pruebas funcionales

Ejecute primero:

```bash
npm install
npm run check
npm run seed
npm run verify
npm run dev
```

## Pruebas recomendadas para la defensa

| # | Flujo | Acción | Resultado esperado |
|---|---|---|---|
| 1 | Cliente | Crear un cliente | Aparece en la lista y en MongoDB |
| 2 | Producto | Crear producto con stock inicial 10 | Producto creado + movimiento Entrada |
| 3 | Compra | Registrar compra `Registrada` | No modifica stock |
| 4 | Compra | Editarla a `Recibida` | Aumenta stock + movimiento Compra |
| 5 | Venta | Vender 2 unidades | Valida stock, descuenta 2, crea DetalleVenta y movimiento Venta |
| 6 | Venta | Intentar vender más que el stock | Operación rechazada sin alterar datos |
| 7 | Detalle | Abrir Detalle de ventas | Muestra la venta automáticamente; no requiere doble registro |
| 8 | Devolución | Devolver 1 unidad | Reingresa 1 al stock + movimiento Devolución |
| 9 | Devolución | Intentar devolver más de lo vendido | Operación rechazada |
| 10 | Inventario | Crear ajuste manual | Modifica stock y crea movimiento Ajuste |
| 11 | Búsqueda | Buscar cliente/producto/venta | Filtra registros correctamente |
| 12 | API | GET `/api/status` | Estado operativo y MongoDB conectada |
| 13 | API | GET `/api/productos` | Respuesta 200 JSON |
| 14 | API | POST `/api/clientes` | Respuesta 201 JSON |
| 15 | Integridad | Ejecutar `npm run verify` | Revisa stock, ventas, detalles y movimientos |
| 16 | Integridad | Intentar borrar venta con devolución | Operación bloqueada |
| 17 | Integridad | Intentar borrar categoría usada | Operación bloqueada |

## Evidencias para el documento IEEE

Capture al menos:

- Panel principal con métricas.
- Listado de productos y stock.
- Registro de una compra.
- Registro de una venta.
- Detalle generado automáticamente.
- Movimiento de inventario asociado.
- Devolución y stock actualizado.
- Colecciones en MongoDB Compass.
- Índices en una colección.
- GET 200 y POST 201 en Postman.
- Repositorio GitHub con README visible.
