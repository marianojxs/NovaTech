# Modelo NoSQL y decisiones de diseño

## Enfoque documental

NovaTech utiliza MongoDB con Mongoose. Cada módulo se representa mediante una colección y los procesos transaccionales guardan tanto referencias `ObjectId` como snapshots legibles de datos relevantes.

Este enfoque permite mantener relaciones funcionales sin convertir el modelo en una réplica directa de una base relacional.

## Colecciones principales

| Colección | Propósito |
|---|---|
| `clientes` | Datos de identificación y contacto de clientes. |
| `productos` | Catálogo de productos, categoría, precio y stock. |
| `categorias` | Clasificación de productos. |
| `proveedores` | Proveedores y datos de contacto. |
| `compras` | Compras realizadas y datos del producto adquirido. |
| `ventas` | Venta principal, cliente, producto, cantidad, total y medio de pago. |
| `detalleventas` | Snapshot detallado generado automáticamente desde una venta. |
| `inventario` | Entradas y salidas trazables por origen y referencia. |
| `devoluciones` | Productos devueltos vinculados a una venta. |
| `metodospago` | Catálogo de medios de pago. |
| `sucursales` | Puntos de operación. |
| `usuarios` | Responsables y roles de las operaciones. |

## Referencias y snapshots

Ejemplo en una venta:

- `clienteId`: referencia al documento de Cliente.
- `cliente`: snapshot del nombre del cliente.
- `productoId`: referencia al Producto.
- `codigoProducto` y `nombreProducto`: snapshot comercial.

La referencia permite validar la relación actual y el snapshot conserva legibilidad histórica.

## Índices

Se utilizan índices únicos para evitar duplicados en identificadores de negocio y índices de texto para acelerar búsquedas frecuentes.

Ejemplos:

- código de producto único;
- identificación de cliente única;
- número de factura único;
- número de compra único;
- índices de texto en nombres, códigos y descripciones.

## Control de inventario

El stock de `productos` se modifica a través de movimientos registrados en `inventario`:

```text
Compra recibida  → Entrada
Venta facturada  → Salida
Devolución       → Entrada
Ajuste manual    → Entrada o Salida
```

El servicio `inventoryService.js` centraliza esta lógica y aplica validaciones para evitar stock negativo.

## Alcance del modelo

La versión desarrollada utiliza una línea de producto por compra y por venta. Este alcance permite demostrar de forma clara referencias, desnormalización, validaciones, índices y consistencia entre colecciones. Una extensión futura podría utilizar arreglos `items` para manejar múltiples productos por documento transaccional.
