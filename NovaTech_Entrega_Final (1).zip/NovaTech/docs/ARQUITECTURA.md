# Arquitectura e integración de NovaTech Solutions

## Arquitectura general

La aplicación utiliza una organización **MVC simplificada** y separa las reglas compartidas en servicios:

- **Models:** esquemas Mongoose, tipos de datos, validaciones e índices.
- **Controllers:** lógica de negocio, validación de referencias y coordinación entre colecciones.
- **Routes:** endpoints web y API.
- **Views:** interfaz EJS + Bootstrap + estilos propios.
- **Services:** reglas reutilizables; `inventoryService.js` centraliza movimientos de stock.
- **Scripts:** carga de datos demo y verificaciones automáticas.

```mermaid
flowchart LR
    UI[Interfaz EJS / Bootstrap] --> R[Express Routes]
    R --> C[Controllers]
    C --> S[Servicios de negocio]
    C --> M[Mongoose Models]
    S --> M
    M --> DB[(MongoDB / NovaTechDB)]
```

## Relaciones funcionales

```mermaid
flowchart TD
    CAT[Categorías] --> PROD[Productos]
    PROV[Proveedores] --> COMP[Compras]
    PROD --> COMP
    COMP -->|Recibida| INV[Inventario]

    CLI[Clientes] --> VEN[Ventas]
    PROD --> VEN
    MP[Métodos de pago] --> VEN
    SUC[Sucursales] --> VEN
    USU[Usuarios] --> VEN
    SUC --> COMP
    USU --> COMP

    VEN --> DET[Detalle de ventas]
    VEN -->|Salida| INV
    VEN --> DEV[Devoluciones]
    DEV -->|Entrada| INV
```

## Reglas de negocio principales

1. **Categoría → Producto:** el producto guarda `categoriaId` y un snapshot con el nombre de la categoría.
2. **Compra recibida → Inventario:** una compra en estado `Recibida` incrementa stock y registra una entrada.
3. **Venta → Detalle + Inventario:** la venta valida stock, toma el precio vigente, calcula total, genera detalle y registra una salida.
4. **Detalle de venta:** funciona como vista documental de solo lectura generada desde Ventas para evitar doble digitación.
5. **Devolución → Inventario:** parte de una venta existente, valida la cantidad acumulada devuelta y registra una entrada.
6. **Inventario:** los movimientos automáticos se administran desde su documento de origen; los ajustes manuales sí se editan directamente.
7. **Integridad histórica:** las transacciones conservan referencias `ObjectId` y snapshots legibles.
8. **Eliminaciones protegidas:** catálogos usados por operaciones no se eliminan directamente.

## Secuencia de una venta

```mermaid
sequenceDiagram
    actor U as Usuario
    participant V as VentaController
    participant P as Producto
    participant DB as MongoDB
    participant I as InventoryService

    U->>V: Envía formulario de venta
    V->>DB: Valida cliente, producto y método de pago
    V->>P: Consulta precio y stock
    P-->>V: Precio + existencias
    V->>V: Calcula total
    V->>DB: Crea Venta
    V->>I: Solicita movimiento Salida
    I->>P: Descuenta stock
    I->>DB: Crea movimiento Inventario
    V->>DB: Crea DetalleVenta
    V-->>U: Redirección a listado
```

## Consistencia y rollback

El servicio `services/inventoryService.js` actualiza el stock y crea el movimiento asociado. Si la creación del movimiento falla, el servicio revierte el cambio en el producto.

Los controladores de compras, ventas y devoluciones utilizan además una estrategia de **rollback compensatorio**. Si una operación compuesta falla después de guardar parcialmente información, el controlador intenta restaurar el estado anterior.

## Alcance

La versión actual modela una línea de producto por compra y por venta. Este alcance permite demostrar de forma clara CRUD, referencias, desnormalización controlada, validaciones, indexación, API y reglas de inventario. Una ampliación posterior puede incorporar múltiples líneas mediante arreglos `items` o documentos de detalle adicionales vinculados a la misma transacción.
