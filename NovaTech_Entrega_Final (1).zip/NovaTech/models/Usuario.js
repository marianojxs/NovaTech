const mongoose = require("mongoose");

const usuarioSchema = new mongoose.Schema(
  {
    usuario: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    nombre: {
      type: String,
      required: true,
      trim: true,
    },

    rol: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
    collection: "usuarios",
  }
);

usuarioSchema.index({ usuario: "text", nombre: "text", rol: "text" });

module.exports = mongoose.model("Usuario", usuarioSchema);