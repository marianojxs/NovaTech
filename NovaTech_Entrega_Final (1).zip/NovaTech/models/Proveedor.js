const mongoose = require("mongoose");

const proveedorSchema = new mongoose.Schema(
  {
    cedulaJuridica: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
    empresa: {
      type: String,
      required: true,
      trim: true,
    },
    contacto: {
      type: String,
      required: true,
      trim: true,
    },
    telefono: {
      type: String,
      required: true,
      trim: true,
    },
    correo: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
    },
    direccion: {
      type: String,
      required: true,
      trim: true,
    },
    estado: {
      type: String,
      enum: ["Activo", "Inactivo"],
      default: "Activo",
    },
  },
  {
    timestamps: true,
    collection: "proveedores",
  }
);

proveedorSchema.index({ empresa: "text", cedulaJuridica: "text", contacto: "text" });

module.exports = mongoose.model("Proveedor", proveedorSchema);
