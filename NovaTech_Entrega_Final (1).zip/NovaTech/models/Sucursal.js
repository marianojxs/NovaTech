const mongoose = require("mongoose");

const sucursalSchema = new mongoose.Schema(
  {
    codigo: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    nombre: {
      type: String,
      required: true,
      trim: true,
    },

    direccion: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
    collection: "sucursales",
  }
);

sucursalSchema.index({ codigo: "text", nombre: "text" });

module.exports = mongoose.model("Sucursal", sucursalSchema);