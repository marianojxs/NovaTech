const mongoose = require("mongoose");

const ventaSchema = new mongoose.Schema(
  {
    factura: {
      type: String,
      required: [true, "El número de factura es obligatorio."],
      unique: true,
      trim: true,
      uppercase: true,
    },
    clienteId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Cliente",
    },
    cliente: {
      type: String,
      required: [true, "El cliente es obligatorio."],
      trim: true,
    },
    fecha: {
      type: Date,
      required: [true, "La fecha es obligatoria."],
    },
    productoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Producto",
    },
    codigoProducto: {
      type: String,
      required: [true, "El código del producto es obligatorio."],
      trim: true,
      uppercase: true,
    },
    nombreProducto: {
      type: String,
      required: [true, "El nombre del producto es obligatorio."],
      trim: true,
    },
    cantidad: {
      type: Number,
      required: [true, "La cantidad es obligatoria."],
      min: [1, "La cantidad debe ser mayor que cero."],
    },
    precioUnitario: {
      type: Number,
      required: [true, "El precio unitario es obligatorio."],
      min: [0, "El precio unitario no puede ser negativo."],
    },
    total: {
      type: Number,
      required: true,
      min: 0,
    },
    metodoPagoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "MetodoPago",
    },
    metodoPago: {
      type: String,
      required: [true, "El método de pago es obligatorio."],
      trim: true,
    },
    sucursalId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Sucursal",
    },
    sucursal: {
      type: String,
      trim: true,
    },
    usuarioId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Usuario",
    },
    registradoPor: {
      type: String,
      trim: true,
    },
    estado: {
      type: String,
      enum: ["Facturada", "Anulada"],
      default: "Facturada",
    },
  },
  {
    timestamps: true,
    collection: "ventas",
  }
);

ventaSchema.index({ factura: "text", cliente: "text", codigoProducto: "text", nombreProducto: "text" });

module.exports = mongoose.model("Venta", ventaSchema);
