const mongoose = require("mongoose");

const devolucionSchema = new mongoose.Schema(
  {
    numero: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      uppercase: true,
    },
    ventaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Venta",
    },
    factura: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
    },
    clienteId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Cliente",
    },
    cliente: {
      type: String,
      required: true,
      trim: true,
    },
    productoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Producto",
    },
    codigoProducto: {
      type: String,
      trim: true,
      uppercase: true,
    },
    producto: {
      type: String,
      required: true,
      trim: true,
    },
    cantidad: {
      type: Number,
      required: true,
      min: [1, "La cantidad devuelta debe ser mayor que cero."],
      default: 1,
    },
    motivo: {
      type: String,
      required: true,
      trim: true,
    },
    fecha: {
      type: Date,
      required: true,
    },
  },
  {
    collection: "devoluciones",
    timestamps: true,
  }
);

devolucionSchema.index({ factura: "text", cliente: "text", producto: "text", numero: "text" });

module.exports = mongoose.model("Devolucion", devolucionSchema);
