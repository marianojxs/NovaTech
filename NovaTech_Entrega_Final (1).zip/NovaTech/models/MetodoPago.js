const mongoose = require("mongoose");

const metodoPagoSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },
  },
  {
    timestamps: true,
    collection: "metodospago",
  }
);

module.exports = mongoose.model("MetodoPago", metodoPagoSchema);
