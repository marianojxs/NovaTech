const mongoose = require("mongoose");

const categoriaSchema = new mongoose.Schema(
  {
    nombre: {
      type: String,
      required: [true, "El nombre de la categoría es obligatorio."],
      unique: true,
      trim: true,
    },

    descripcion: {
      type: String,
      required: [true, "La descripción es obligatoria."],
      trim: true,
    },

    estado: {
      type: String,
      enum: ["Activa", "Inactiva"],
      default: "Activa",
    },
  },
  {
    timestamps: true,
    collection: "categorias",
  }
);

// Índice para búsquedas
categoriaSchema.index({
  nombre: "text",
  descripcion: "text",
});

module.exports = mongoose.model("Categoria", categoriaSchema);