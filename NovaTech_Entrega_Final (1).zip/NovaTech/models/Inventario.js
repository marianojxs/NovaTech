const mongoose = require("mongoose");

const inventarioSchema = new mongoose.Schema(
  {
    productoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Producto",
    },
    codigoProducto: {
      type: String,
      trim: true,
      uppercase: true,
    },
    producto: {
      type: String,
      required: [true, "El producto es obligatorio"],
      trim: true,
    },
    tipo: {
      type: String,
      required: [true, "El tipo de movimiento es obligatorio"],
      enum: ["Entrada", "Salida"],
    },
    cantidad: {
      type: Number,
      required: [true, "La cantidad es obligatoria"],
      min: [1, "La cantidad debe ser mayor que cero"],
    },
    fecha: {
      type: Date,
      required: [true, "La fecha es obligatoria"],
    },
    origen: {
      type: String,
      enum: ["Compra", "Venta", "Devolución", "Ajuste"],
      default: "Ajuste",
    },
    referencia: {
      type: String,
      trim: true,
    },
    documentoId: {
      type: mongoose.Schema.Types.ObjectId,
      index: true,
    },
  },
  {
    timestamps: true,
    collection: "inventario",
  }
);

inventarioSchema.index({ producto: "text", codigoProducto: "text", referencia: "text" });

module.exports = mongoose.model("Inventario", inventarioSchema);
