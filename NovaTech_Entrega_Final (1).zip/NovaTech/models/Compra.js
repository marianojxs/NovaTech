const mongoose = require("mongoose");

const compraSchema = new mongoose.Schema(
  {
    numeroCompra: {
      type: String,
      required: [true, "El número de compra es obligatorio."],
      unique: true,
      trim: true,
      uppercase: true,
    },
    fecha: {
      type: Date,
      required: [true, "La fecha es obligatoria."],
    },
    proveedorId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Proveedor",
    },
    proveedor: {
      type: String,
      required: [true, "El proveedor es obligatorio."],
      trim: true,
    },
    productoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Producto",
    },
    codigoProducto: {
      type: String,
      required: [true, "El código del producto es obligatorio."],
      trim: true,
      uppercase: true,
    },
    nombreProducto: {
      type: String,
      required: [true, "El nombre del producto es obligatorio."],
      trim: true,
    },
    cantidad: {
      type: Number,
      required: [true, "La cantidad es obligatoria."],
      min: [1, "La cantidad debe ser mayor que cero."],
    },
    precioUnitario: {
      type: Number,
      required: [true, "El precio unitario es obligatorio."],
      min: [0, "El precio no puede ser negativo."],
    },
    total: {
      type: Number,
      required: true,
      min: 0,
    },
    estado: {
      type: String,
      enum: ["Registrada", "Recibida", "Cancelada"],
      default: "Registrada",
    },
    sucursalId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Sucursal",
    },
    sucursal: {
      type: String,
      trim: true,
    },
    usuarioId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Usuario",
    },
    registradoPor: {
      type: String,
      trim: true,
    },
  },
  {
    timestamps: true,
    collection: "compras",
  }
);

compraSchema.index({ proveedor: "text", nombreProducto: "text", numeroCompra: "text", codigoProducto: "text" });

module.exports = mongoose.model("Compra", compraSchema);
