const mongoose = require("mongoose");

const clienteSchema = new mongoose.Schema(
  {
    identificacion: {
      type: String,
      required: [true, "La identificación es obligatoria"],
      unique: true,
      trim: true,
    },

    nombre: {
      type: String,
      required: [true, "El nombre es obligatorio"],
      trim: true,
    },

    telefono: {
      type: String,
      required: [true, "El teléfono es obligatorio"],
      trim: true,
    },

    correo: {
      type: String,
      required: [true, "El correo electrónico es obligatorio"],
      trim: true,
      lowercase: true,
    },

    direccion: {
      type: String,
      required: [true, "La dirección es obligatoria"],
      trim: true,
    },

    estado: {
      type: String,
      enum: ["Activo", "Inactivo"],
      default: "Activo",
    },
  },
  {
    timestamps: true,
    collection: "clientes",
  }
);

clienteSchema.index({ nombre: "text", identificacion: "text", correo: "text" });

module.exports = mongoose.model("Cliente", clienteSchema);