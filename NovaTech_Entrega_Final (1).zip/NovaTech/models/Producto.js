const mongoose = require("mongoose");

const productoSchema = new mongoose.Schema(
  {
    codigo: {
      type: String,
      required: [true, "El código del producto es obligatorio"],
      unique: true,
      trim: true,
      uppercase: true,
    },
    nombre: {
      type: String,
      required: [true, "El nombre del producto es obligatorio"],
      trim: true,
    },
    descripcion: {
      type: String,
      required: [true, "La descripción es obligatoria"],
      trim: true,
    },
    categoriaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Categoria",
    },
    // Se conserva el nombre como snapshot para facilitar consultas NoSQL.
    categoria: {
      type: String,
      required: [true, "La categoría es obligatoria"],
      trim: true,
    },
    marca: {
      type: String,
      required: [true, "La marca es obligatoria"],
      trim: true,
    },
    precio: {
      type: Number,
      required: [true, "El precio es obligatorio"],
      min: [0, "El precio no puede ser negativo"],
    },
    stock: {
      type: Number,
      required: [true, "El stock es obligatorio"],
      min: [0, "El stock no puede ser negativo"],
      default: 0,
    },
    estado: {
      type: String,
      enum: ["Disponible", "Agotado", "Descontinuado"],
      default: "Disponible",
    },
  },
  {
    timestamps: true,
    collection: "productos",
  }
);

productoSchema.index({ nombre: "text", codigo: "text", categoria: "text", marca: "text" });

module.exports = mongoose.model("Producto", productoSchema);
