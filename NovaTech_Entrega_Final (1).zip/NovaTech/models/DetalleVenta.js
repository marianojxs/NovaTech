const mongoose = require("mongoose");

const detalleVentaSchema = new mongoose.Schema(
  {
    ventaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Venta",
      index: true,
    },
    clienteId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Cliente",
    },
    productoId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Producto",
    },
    numeroVenta: {
      type: String,
      required: [true, "El número de venta es obligatorio."],
      trim: true,
      uppercase: true,
    },
    fechaVenta: {
      type: Date,
      required: [true, "La fecha de venta es obligatoria."],
    },
    cliente: {
      type: String,
      required: [true, "El nombre del cliente es obligatorio."],
      trim: true,
    },
    codigoProducto: {
      type: String,
      required: [true, "El código del producto es obligatorio."],
      trim: true,
      uppercase: true,
    },
    nombreProducto: {
      type: String,
      required: [true, "El nombre del producto es obligatorio."],
      trim: true,
    },
    cantidad: {
      type: Number,
      required: [true, "La cantidad es obligatoria."],
      min: [1, "La cantidad debe ser mayor que cero."],
    },
    precioUnitario: {
      type: Number,
      required: [true, "El precio unitario es obligatorio."],
      min: [0, "El precio no puede ser negativo."],
    },
    subtotal: {
      type: Number,
      required: true,
      min: 0,
    },
    estado: {
      type: String,
      enum: ["Registrada", "Facturada", "Cancelada"],
      default: "Facturada",
    },
  },
  {
    timestamps: true,
    collection: "detalleventas",
  }
);

detalleVentaSchema.index({ numeroVenta: "text", cliente: "text", codigoProducto: "text", nombreProducto: "text" });

module.exports = mongoose.model("DetalleVenta", detalleVentaSchema);
