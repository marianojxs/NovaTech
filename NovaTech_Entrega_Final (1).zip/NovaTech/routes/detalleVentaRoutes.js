const express = require("express");
const { listarDetallesVenta } = require("../controllers/detalleVentaController");

const router = express.Router();
router.get("/", listarDetallesVenta);

module.exports = router;
