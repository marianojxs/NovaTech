const express = require("express");

const {

listarUsuarios,
mostrarFormularioNuevo,
crearUsuario,
mostrarFormularioEditar,
actualizarUsuario,
eliminarUsuario,

} = require("../controllers/usuarioController");

const router = express.Router();

router.get("/", listarUsuarios);

router.get("/nuevo", mostrarFormularioNuevo);

router.post("/", crearUsuario);

router.get("/:id/editar", mostrarFormularioEditar);

router.put("/:id", actualizarUsuario);

router.delete("/:id", eliminarUsuario);

module.exports = router;