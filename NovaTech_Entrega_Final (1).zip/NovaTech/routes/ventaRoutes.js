const express=require("express");

const{

listarVentas,
mostrarFormularioNuevo,
crearVenta,
mostrarFormularioEditar,
actualizarVenta,
eliminarVenta

}=require("../controllers/ventaController");

const router=express.Router();

router.get("/",listarVentas);

router.get("/nuevo",mostrarFormularioNuevo);

router.post("/",crearVenta);

router.get("/:id/editar",mostrarFormularioEditar);

router.put("/:id",actualizarVenta);

router.delete("/:id",eliminarVenta);

module.exports=router;