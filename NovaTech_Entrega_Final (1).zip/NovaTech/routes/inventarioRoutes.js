const express = require("express");

const {
  listarInventario,
  mostrarFormularioNuevo,
  crearInventario,
  mostrarFormularioEditar,
  actualizarInventario,
  eliminarInventario,
} = require("../controllers/inventarioController");

const router = express.Router();

router.get("/", listarInventario);

router.get("/nuevo", mostrarFormularioNuevo);

router.post("/", crearInventario);

router.get("/:id/editar", mostrarFormularioEditar);

router.put("/:id", actualizarInventario);

router.delete("/:id", eliminarInventario);

module.exports = router;