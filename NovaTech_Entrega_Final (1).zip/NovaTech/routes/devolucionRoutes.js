const express = require("express");
const devolucionController = require("../controllers/devolucionController");

const router = express.Router();

router.get("/", devolucionController.inicio);
router.get("/nuevo", devolucionController.nuevo);
router.post("/", devolucionController.guardar);
router.get("/:id/editar", devolucionController.editar);
router.put("/:id", devolucionController.actualizar);
router.delete("/:id", devolucionController.eliminar);

module.exports = router;
