const express = require("express");

const {
  listarClientes,
  mostrarFormularioNuevo,
  crearCliente,
  mostrarFormularioEditar,
  actualizarCliente,
  eliminarCliente,
} = require("../controllers/clienteController");

const router = express.Router();

// Mostrar todos los clientes
router.get("/", listarClientes);

// Mostrar formulario de registro
router.get("/nuevo", mostrarFormularioNuevo);

// Guardar cliente
router.post("/", crearCliente);

// Mostrar formulario de edición
router.get("/:id/editar", mostrarFormularioEditar);

// Actualizar cliente
router.put("/:id", actualizarCliente);

// Eliminar cliente
router.delete("/:id", eliminarCliente);

module.exports = router;