const express = require("express");

const {
  listarProductos,
  mostrarFormularioNuevo,
  crearProducto,
  mostrarFormularioEditar,
  actualizarProducto,
  eliminarProducto,
} = require("../controllers/productoController");


const router = express.Router();


// Mostrar todos los productos
router.get("/", listarProductos);


// Mostrar formulario de registro
router.get("/nuevo", mostrarFormularioNuevo);


// Guardar producto
router.post("/", crearProducto);


// Mostrar formulario de edición
router.get("/:id/editar", mostrarFormularioEditar);


// Actualizar producto
router.put("/:id", actualizarProducto);


// Eliminar producto
router.delete("/:id", eliminarProducto);


module.exports = router;