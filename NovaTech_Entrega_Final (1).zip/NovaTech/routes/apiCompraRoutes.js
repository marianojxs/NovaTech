const express = require("express");

const {
  listarComprasApi,
  crearCompraApi,
} = require("../controllers/compraController");

const router = express.Router();

router.get("/", listarComprasApi);

router.post("/", crearCompraApi);

module.exports = router;