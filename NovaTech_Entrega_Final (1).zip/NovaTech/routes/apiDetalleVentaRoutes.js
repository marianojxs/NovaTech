const express = require("express");
const { listarDetallesVentaApi } = require("../controllers/detalleVentaController");

const router = express.Router();
router.get("/", listarDetallesVentaApi);

module.exports = router;
