const express = require("express");

const {
  listarInventarioApi,
  crearInventarioApi,
} = require("../controllers/inventarioController");

const router = express.Router();

router.get("/", listarInventarioApi);

router.post("/", crearInventarioApi);

module.exports = router;