const express = require("express");

const {
  listarCategoriasApi,
  crearCategoriaApi,
} = require("../controllers/categoriaController");

const router = express.Router();

router.get("/", listarCategoriasApi);

router.post("/", crearCategoriaApi);

module.exports = router;