const express = require("express");

const {
  listarMetodosPagoApi,
  crearMetodoPagoApi,
} = require("../controllers/metodoPagoController");

const router = express.Router();

// Consultar métodos de pago
router.get("/", listarMetodosPagoApi);

// Registrar método de pago
router.post("/", crearMetodoPagoApi);

module.exports = router;