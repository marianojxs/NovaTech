const express = require("express");

const {
  listarCompras,
  mostrarFormularioNuevo,
  crearCompra,
  mostrarFormularioEditar,
  actualizarCompra,
  eliminarCompra,
} = require("../controllers/compraController");

const router = express.Router();

router.get("/", listarCompras);

router.get("/nuevo", mostrarFormularioNuevo);

router.post("/", crearCompra);

router.get("/:id/editar", mostrarFormularioEditar);

router.put("/:id", actualizarCompra);

router.delete("/:id", eliminarCompra);

module.exports = router;