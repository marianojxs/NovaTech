const express = require("express");

const {
  listarProductosApi,
  crearProductoApi,
} = require("../controllers/productoController");

const router = express.Router();


// Consultar productos
router.get("/", listarProductosApi);


// Registrar producto
router.post("/", crearProductoApi);


module.exports = router;