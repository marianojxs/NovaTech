const express = require("express");

const {
  listarCategorias,
  mostrarFormularioNuevo,
  crearCategoria,
  mostrarFormularioEditar,
  actualizarCategoria,
  eliminarCategoria,
} = require("../controllers/categoriaController");

const router = express.Router();

router.get("/", listarCategorias);

router.get("/nuevo", mostrarFormularioNuevo);

router.post("/", crearCategoria);

router.get("/:id/editar", mostrarFormularioEditar);

router.put("/:id", actualizarCategoria);

router.delete("/:id", eliminarCategoria);

module.exports = router;