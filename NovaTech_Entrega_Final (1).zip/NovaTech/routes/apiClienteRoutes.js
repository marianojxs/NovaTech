const express = require("express");

const {
  listarClientesApi,
  crearClienteApi,
} = require("../controllers/clienteController");

const router = express.Router();

// Consultar clientes
router.get("/", listarClientesApi);

// Registrar cliente
router.post("/", crearClienteApi);

module.exports = router;