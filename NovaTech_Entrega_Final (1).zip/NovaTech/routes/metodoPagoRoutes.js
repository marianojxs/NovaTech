const express = require("express");

const {
  listarMetodosPago,
  mostrarFormularioNuevo,
  crearMetodoPago,
  mostrarFormularioEditar,
  actualizarMetodoPago,
  eliminarMetodoPago,
} = require("../controllers/metodoPagoController");

const router = express.Router();

// Mostrar todos los métodos de pago
router.get("/", listarMetodosPago);

// Mostrar formulario de registro
router.get("/nuevo", mostrarFormularioNuevo);

// Guardar método de pago
router.post("/", crearMetodoPago);

// Mostrar formulario de edición
router.get("/:id/editar", mostrarFormularioEditar);

// Actualizar método de pago
router.put("/:id", actualizarMetodoPago);

// Eliminar método de pago
router.delete("/:id", eliminarMetodoPago);

module.exports = router;