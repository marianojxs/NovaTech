const express = require("express");
const { listarVentasApi, crearVentaApi } = require("../controllers/ventaController");

const router = express.Router();
router.get("/", listarVentasApi);
router.post("/", crearVentaApi);

module.exports = router;
