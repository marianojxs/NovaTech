const express = require("express");

const {
  listarProveedores,
  mostrarFormularioNuevo,
  crearProveedor,
  mostrarFormularioEditar,
  actualizarProveedor,
  eliminarProveedor,
} = require("../controllers/proveedorController");

const router = express.Router();

// Mostrar todos los proveedores
router.get("/", listarProveedores);

// Mostrar formulario de registro
router.get("/nuevo", mostrarFormularioNuevo);

// Guardar proveedor
router.post("/", crearProveedor);

// Mostrar formulario de edición
router.get("/:id/editar", mostrarFormularioEditar);

// Actualizar proveedor
router.put("/:id", actualizarProveedor);

// Eliminar proveedor
router.delete("/:id", eliminarProveedor);

module.exports = router;