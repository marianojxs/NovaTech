const express = require("express");

const {
  listarSucursales,
  mostrarFormularioNuevo,
  crearSucursal,
  mostrarFormularioEditar,
  actualizarSucursal,
  eliminarSucursal,
} = require("../controllers/sucursalController");

const router = express.Router();

// Mostrar todas las sucursales
router.get("/", listarSucursales);

// Formulario nuevo
router.get("/nuevo", mostrarFormularioNuevo);

// Guardar sucursal
router.post("/", crearSucursal);

// Formulario editar
router.get("/:id/editar", mostrarFormularioEditar);

// Actualizar sucursal
router.put("/:id", actualizarSucursal);

// Eliminar sucursal
router.delete("/:id", eliminarSucursal);

module.exports = router;