const Cliente = require("../models/Cliente");
const Venta = require("../models/Venta");
const Devolucion = require("../models/Devolucion");

// Mostrar todos los clientes y permitir búsquedas
const listarClientes = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {
      filtro = {
        $or: [
          { nombre: { $regex: buscar, $options: "i" } },
          { identificacion: { $regex: buscar, $options: "i" } },
        ],
      };
    }

    const clientes = await Cliente.find(filtro).sort({ createdAt: -1 });

    res.render("clientes/lista", {
      clientes,
      buscar,
    });
  } catch (error) {
    console.error("Error al consultar clientes:", error);
    res.status(500).send("No fue posible consultar los clientes.");
  }
};

// Mostrar formulario para registrar un cliente
const mostrarFormularioNuevo = (req, res) => {
  res.render("clientes/nuevo", {
    error: null,
    cliente: {},
  });
};

// Guardar un nuevo cliente
const crearCliente = async (req, res) => {
  try {
    const nuevoCliente = new Cliente({
      identificacion: req.body.identificacion,
      nombre: req.body.nombre,
      telefono: req.body.telefono,
      correo: req.body.correo,
      direccion: req.body.direccion,
      estado: req.body.estado,
    });

    await nuevoCliente.save();

    res.redirect("/clientes");
  } catch (error) {
    console.error("Error al registrar cliente:", error);

    let mensaje = "No fue posible registrar el cliente.";

    if (error.code === 11000) {
      mensaje = "Ya existe un cliente con esa identificación.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("clientes/nuevo", {
      error: mensaje,
      cliente: req.body,
    });
  }
};

// Mostrar formulario para editar un cliente
const mostrarFormularioEditar = async (req, res) => {
  try {
    const cliente = await Cliente.findById(req.params.id);

    if (!cliente) {
      return res.status(404).send("Cliente no encontrado.");
    }

    res.render("clientes/editar", {
      cliente,
      error: null,
    });
  } catch (error) {
    console.error("Error al consultar el cliente:", error);
    res.status(500).send("No fue posible consultar el cliente.");
  }
};

// Actualizar un cliente
const actualizarCliente = async (req, res) => {
  try {
    const clienteActualizado = await Cliente.findByIdAndUpdate(
      req.params.id,
      {
        identificacion: req.body.identificacion,
        nombre: req.body.nombre,
        telefono: req.body.telefono,
        correo: req.body.correo,
        direccion: req.body.direccion,
        estado: req.body.estado,
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!clienteActualizado) {
      return res.status(404).send("Cliente no encontrado.");
    }

    res.redirect("/clientes");
  } catch (error) {
    console.error("Error al actualizar cliente:", error);

    let mensaje = "No fue posible actualizar el cliente.";

    if (error.code === 11000) {
      mensaje = "Ya existe otro cliente con esa identificación.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("clientes/editar", {
      error: mensaje,
      cliente: {
        _id: req.params.id,
        ...req.body,
      },
    });
  }
};

// Eliminar un cliente
const eliminarCliente = async (req, res) => {
  try {
    const [ventaAsociada, devolucionAsociada] = await Promise.all([
      Venta.exists({ clienteId: req.params.id }),
      Devolucion.exists({ clienteId: req.params.id }),
    ]);
    if (ventaAsociada || devolucionAsociada) {
      return res.status(400).send(
        "No se puede eliminar el cliente porque tiene ventas o devoluciones asociadas. Puede marcarlo como Inactivo."
      );
    }

    const clienteEliminado = await Cliente.findByIdAndDelete(req.params.id);

    if (!clienteEliminado) {
      return res.status(404).send("Cliente no encontrado.");
    }

    res.redirect("/clientes");
  } catch (error) {
    console.error("Error al eliminar cliente:", error);
    res.status(500).send("No fue posible eliminar el cliente.");
  }
};
// API: consultar todos los clientes
const listarClientesApi = async (req, res) => {
  try {
    const clientes = await Cliente.find().sort({ createdAt: -1 });

    res.status(200).json({
      cantidad: clientes.length,
      clientes: clientes,
    });
  } catch (error) {
    console.error("Error en API al consultar clientes:", error);

    res.status(500).json({
      mensaje: "No fue posible consultar los clientes.",
    });
  }
};

// API: registrar un cliente
const crearClienteApi = async (req, res) => {
  try {
    const nuevoCliente = new Cliente({
      identificacion: req.body.identificacion,
      nombre: req.body.nombre,
      telefono: req.body.telefono,
      correo: req.body.correo,
      direccion: req.body.direccion,
      estado: req.body.estado || "Activo",
    });

    const clienteGuardado = await nuevoCliente.save();

    res.status(201).json({
      mensaje: "Cliente registrado correctamente.",
      cliente: clienteGuardado,
    });
  } catch (error) {
    console.error("Error en API al registrar cliente:", error);

    let mensaje = "No fue posible registrar el cliente.";

    if (error.code === 11000) {
      mensaje = "Ya existe un cliente con esa identificación.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).json({
      mensaje: mensaje,
    });
  }
};

module.exports = {
  listarClientes,
  mostrarFormularioNuevo,
  crearCliente,
  mostrarFormularioEditar,
  actualizarCliente,
  eliminarCliente,
  listarClientesApi,
  crearClienteApi,
};