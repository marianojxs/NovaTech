const Proveedor = require("../models/Proveedor");
const Compra = require("../models/Compra");

// Mostrar todos los proveedores y permitir búsquedas
const listarProveedores = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {
      filtro = {
        $or: [
          { empresa: { $regex: buscar, $options: "i" } },
          { cedulaJuridica: { $regex: buscar, $options: "i" } },
        ],
      };
    }

    const proveedores = await Proveedor.find(filtro).sort({ createdAt: -1 });

    res.render("proveedores/lista", {
      proveedores,
      buscar,
    });
  } catch (error) {
    console.error("Error al consultar proveedores:", error);
    res.status(500).send("No fue posible consultar los proveedores.");
  }
};

// Mostrar formulario para registrar un proveedor
const mostrarFormularioNuevo = (req, res) => {
  res.render("proveedores/nuevo", {
    error: null,
    proveedor: {},
  });
};

// Guardar un proveedor
const crearProveedor = async (req, res) => {
  try {
    const nuevoProveedor = new Proveedor({
      cedulaJuridica: req.body.cedulaJuridica,
      empresa: req.body.empresa,
      contacto: req.body.contacto,
      telefono: req.body.telefono,
      correo: req.body.correo,
      direccion: req.body.direccion,
      estado: req.body.estado,
    });

    await nuevoProveedor.save();

    res.redirect("/proveedores");
  } catch (error) {
    console.error("Error al registrar proveedor:", error);

    let mensaje = "No fue posible registrar el proveedor.";

    if (error.code === 11000) {
      mensaje = "Ya existe un proveedor con esa cédula jurídica.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("proveedores/nuevo", {
      error: mensaje,
      proveedor: req.body,
    });
  }
};

// Mostrar formulario para editar
const mostrarFormularioEditar = async (req, res) => {
  try {
    const proveedor = await Proveedor.findById(req.params.id);

    if (!proveedor) {
      return res.status(404).send("Proveedor no encontrado.");
    }

    res.render("proveedores/editar", {
      proveedor,
      error: null,
    });
  } catch (error) {
    console.error("Error al consultar proveedor:", error);
    res.status(500).send("No fue posible consultar el proveedor.");
  }
};

// Actualizar proveedor
const actualizarProveedor = async (req, res) => {
  try {
    const proveedorActualizado = await Proveedor.findByIdAndUpdate(
      req.params.id,
      {
        cedulaJuridica: req.body.cedulaJuridica,
        empresa: req.body.empresa,
        contacto: req.body.contacto,
        telefono: req.body.telefono,
        correo: req.body.correo,
        direccion: req.body.direccion,
        estado: req.body.estado,
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!proveedorActualizado) {
      return res.status(404).send("Proveedor no encontrado.");
    }

    res.redirect("/proveedores");
  } catch (error) {
    console.error("Error al actualizar proveedor:", error);

    const mensaje = error.code === 11000
      ? "Ya existe otro proveedor con esa cédula jurídica."
      : "No fue posible actualizar el proveedor.";

    res.status(400).render("proveedores/editar", {
      error: mensaje,
      proveedor: {
        _id: req.params.id,
        ...req.body,
      },
    });
  }
};

// Eliminar proveedor
const eliminarProveedor = async (req, res) => {
  try {
    const compraAsociada = await Compra.exists({ proveedorId: req.params.id });
    if (compraAsociada) {
      return res.status(400).send(
        "No se puede eliminar el proveedor porque tiene compras asociadas. Puede marcarlo como Inactivo."
      );
    }

    const proveedorEliminado = await Proveedor.findByIdAndDelete(req.params.id);

    if (!proveedorEliminado) {
      return res.status(404).send("Proveedor no encontrado.");
    }

    res.redirect("/proveedores");
  } catch (error) {
    console.error("Error al eliminar proveedor:", error);
    res.status(500).send("No fue posible eliminar el proveedor.");
  }
};

module.exports = {
  listarProveedores,
  mostrarFormularioNuevo,
  crearProveedor,
  mostrarFormularioEditar,
  actualizarProveedor,
  eliminarProveedor,
};