const Cliente = require("../models/Cliente");
const Producto = require("../models/Producto");
const Proveedor = require("../models/Proveedor");
const Categoria = require("../models/Categoria");
const Compra = require("../models/Compra");
const Venta = require("../models/Venta");
const Devolucion = require("../models/Devolucion");
const Inventario = require("../models/Inventario");

const inicio = async (req, res) => {
  try {
    const [
      clientes,
      productos,
      proveedores,
      categorias,
      compras,
      ventas,
      devoluciones,
      movimientos,
      stockAgotado,
      resumenVentas,
      resumenCompras,
      resumenStock,
      ventasRecientes,
      movimientosRecientes,
      stockBajo,
      productosDestacados,
    ] = await Promise.all([
      Cliente.countDocuments(),
      Producto.countDocuments(),
      Proveedor.countDocuments(),
      Categoria.countDocuments(),
      Compra.countDocuments(),
      Venta.countDocuments(),
      Devolucion.countDocuments(),
      Inventario.countDocuments(),
      Producto.countDocuments({ stock: 0, estado: { $ne: "Descontinuado" } }),
      Venta.aggregate([
        { $match: { estado: "Facturada" } },
        {
          $group: {
            _id: null,
            totalFacturado: { $sum: "$total" },
            unidadesVendidas: { $sum: "$cantidad" },
          },
        },
      ]),
      Compra.aggregate([
        { $match: { estado: "Recibida" } },
        {
          $group: {
            _id: null,
            totalComprado: { $sum: "$total" },
            unidadesRecibidas: { $sum: "$cantidad" },
          },
        },
      ]),
      Producto.aggregate([
        {
          $group: {
            _id: null,
            unidadesStock: { $sum: "$stock" },
            valorInventario: { $sum: { $multiply: ["$stock", "$precio"] } },
          },
        },
      ]),
      Venta.find().sort({ createdAt: -1 }).limit(5),
      Inventario.find().sort({ createdAt: -1 }).limit(6),
      Producto.find({ stock: { $lte: 5 }, estado: { $ne: "Descontinuado" } })
        .sort({ stock: 1, nombre: 1 })
        .limit(5),
      Venta.aggregate([
        { $match: { estado: "Facturada" } },
        {
          $group: {
            _id: {
              productoId: "$productoId",
              codigo: "$codigoProducto",
              nombre: "$nombreProducto",
            },
            unidades: { $sum: "$cantidad" },
            facturas: { $sum: 1 },
            ingresos: { $sum: "$total" },
          },
        },
        { $sort: { unidades: -1, ingresos: -1 } },
        { $limit: 5 },
      ]),
    ]);

    const ventasAgg = resumenVentas[0] || {};
    const comprasAgg = resumenCompras[0] || {};
    const stockAgg = resumenStock[0] || {};

    res.render("inicio", {
      metricas: {
        clientes,
        productos,
        proveedores,
        categorias,
        compras,
        ventas,
        devoluciones,
        movimientos,
        stockAgotado,
        totalFacturado: ventasAgg.totalFacturado || 0,
        unidadesVendidas: ventasAgg.unidadesVendidas || 0,
        totalComprado: comprasAgg.totalComprado || 0,
        unidadesRecibidas: comprasAgg.unidadesRecibidas || 0,
        unidadesStock: stockAgg.unidadesStock || 0,
        valorInventario: stockAgg.valorInventario || 0,
      },
      ventasRecientes,
      movimientosRecientes,
      stockBajo,
      productosDestacados,
    });
  } catch (error) {
    console.error("Error al cargar el panel principal:", error);
    res.render("inicio", {
      metricas: {},
      ventasRecientes: [],
      movimientosRecientes: [],
      stockBajo: [],
      productosDestacados: [],
    });
  }
};

module.exports = { inicio };
