const Sucursal = require("../models/Sucursal");
const Compra = require("../models/Compra");
const Venta = require("../models/Venta");

// Mostrar sucursales
const listarSucursales = async (req, res) => {
  try {

    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {

      filtro = {
        $or: [
          { codigo: { $regex: buscar, $options: "i" } },
          { nombre: { $regex: buscar, $options: "i" } },
        ],
      };

    }

    const sucursales = await Sucursal.find(filtro).sort({ createdAt: -1 });
    res.render("sucursales/lista", {
      sucursales,
      buscar,
    });

  } catch (error) {

    console.error(error);

    res.status(500).send("No fue posible consultar las sucursales.");

  }
};

// Formulario nuevo

const mostrarFormularioNuevo = (req, res) => {

  res.render("sucursales/nuevo", {
    error: null,
    sucursal: {},
  });

};

// Crear

const crearSucursal = async (req, res) => {

  try {

    const nuevaSucursal = new Sucursal({

      codigo: req.body.codigo,
      nombre: req.body.nombre,
      direccion: req.body.direccion,

    });

    await nuevaSucursal.save();

    res.redirect("/sucursales");

  } catch (error) {

    let mensaje = "No fue posible registrar la sucursal.";

    if (error.code === 11000) {

      mensaje = "Ya existe una sucursal con ese código.";

    }

    res.status(400).render("sucursales/nuevo", {

      error: mensaje,
      sucursal: req.body,

    });

  }

};

// Formulario editar

const mostrarFormularioEditar = async (req, res) => {

  try {

    const sucursal = await Sucursal.findById(req.params.id);

    if (!sucursal) {

      return res.status(404).send("Sucursal no encontrada.");

    }

    res.render("sucursales/editar", {

      sucursal,
      error: null,

    });

  } catch (error) {

    res.status(500).send("No fue posible consultar la sucursal.");

  }

};

// Actualizar

const actualizarSucursal = async (req, res) => {

  try {

    const sucursal = await Sucursal.findByIdAndUpdate(

      req.params.id,

      {

        codigo: req.body.codigo,
        nombre: req.body.nombre,
        direccion: req.body.direccion,

      },

      {

        new: true,
        runValidators: true,

      }

    );

    if (!sucursal) {

      return res.status(404).send("Sucursal no encontrada.");

    }

    res.redirect("/sucursales");

  } catch (error) {

    const mensaje = error.code === 11000
      ? "Ya existe otra sucursal con ese código."
      : "No fue posible actualizar la sucursal.";

    res.status(400).render("sucursales/editar", {

      error: mensaje,

      sucursal: {

        _id: req.params.id,

        ...req.body,

      },

    });

  }

};

// Eliminar

const eliminarSucursal = async (req, res) => {

  try {

    const [compraAsociada, ventaAsociada] = await Promise.all([
      Compra.exists({ sucursalId: req.params.id }),
      Venta.exists({ sucursalId: req.params.id }),
    ]);
    if (compraAsociada || ventaAsociada) {
      return res.status(400).send(
        "No se puede eliminar la sucursal porque tiene compras o ventas asociadas."
      );
    }

    const sucursal = await Sucursal.findByIdAndDelete(req.params.id);

    if (!sucursal) {

      return res.status(404).send("Sucursal no encontrada.");

    }

    res.redirect("/sucursales");

  } catch (error) {

    res.status(500).send("No fue posible eliminar la sucursal.");

  }

};

module.exports = {

  listarSucursales,
  mostrarFormularioNuevo,
  crearSucursal,
  mostrarFormularioEditar,
  actualizarSucursal,
  eliminarSucursal,

};