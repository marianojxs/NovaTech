const MetodoPago = require("../models/MetodoPago");
const Venta = require("../models/Venta");

// Mostrar todos los métodos de pago y permitir búsquedas
const listarMetodosPago = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {
      filtro = {
        nombre: { $regex: buscar, $options: "i" },
      };
    }

    const metodosPago = await MetodoPago.find(filtro).sort({ createdAt: -1 });

    res.render("metodosPago/lista", {
      metodosPago,
      buscar,
    });
  } catch (error) {
    console.error("Error al consultar métodos de pago:", error);
    res.status(500).send("No fue posible consultar los métodos de pago.");
  }
};

// Mostrar formulario para registrar un método de pago
const mostrarFormularioNuevo = (req, res) => {
  res.render("metodosPago/nuevo", {
    error: null,
    metodoPago: {},
  });
};

// Guardar un nuevo método de pago
const crearMetodoPago = async (req, res) => {
  try {
    const nuevoMetodoPago = new MetodoPago({
      nombre: req.body.nombre,
    });

    await nuevoMetodoPago.save();

    res.redirect("/metodos-pago");
  } catch (error) {
    console.error("Error al registrar método de pago:", error);

    let mensaje = "No fue posible registrar el método de pago.";

    if (error.code === 11000) {
      mensaje = "Ya existe un método de pago con ese nombre.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("metodosPago/nuevo", {
      error: mensaje,
      metodoPago: req.body,
    });
  }
};

// Mostrar formulario para editar un método de pago
const mostrarFormularioEditar = async (req, res) => {
  try {
    const metodoPago = await MetodoPago.findById(req.params.id);

    if (!metodoPago) {
      return res.status(404).send("Método de pago no encontrado.");
    }

    res.render("metodosPago/editar", {
      metodoPago,
      error: null,
    });
  } catch (error) {
    console.error("Error al consultar el método de pago:", error);
    res.status(500).send("No fue posible consultar el método de pago.");
  }
};

// Actualizar un método de pago
const actualizarMetodoPago = async (req, res) => {
  try {
    const metodoPagoActualizado = await MetodoPago.findByIdAndUpdate(
      req.params.id,
      {
        nombre: req.body.nombre,
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!metodoPagoActualizado) {
      return res.status(404).send("Método de pago no encontrado.");
    }

    res.redirect("/metodos-pago");
  } catch (error) {
    console.error("Error al actualizar método de pago:", error);

    let mensaje = "No fue posible actualizar el método de pago.";

    if (error.code === 11000) {
      mensaje = "Ya existe otro método de pago con ese nombre.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("metodosPago/editar", {
      error: mensaje,
      metodoPago: {
        _id: req.params.id,
        ...req.body,
      },
    });
  }
};

// Eliminar un método de pago
const eliminarMetodoPago = async (req, res) => {
  try {
    const ventaAsociada = await Venta.exists({ metodoPagoId: req.params.id });
    if (ventaAsociada) {
      return res.status(400).send(
        "No se puede eliminar el método de pago porque está asociado a ventas existentes."
      );
    }

    const metodoPagoEliminado = await MetodoPago.findByIdAndDelete(req.params.id);

    if (!metodoPagoEliminado) {
      return res.status(404).send("Método de pago no encontrado.");
    }

    res.redirect("/metodos-pago");
  } catch (error) {
    console.error("Error al eliminar método de pago:", error);
    res.status(500).send("No fue posible eliminar el método de pago.");
  }
};

// API: consultar todos los métodos de pago
const listarMetodosPagoApi = async (req, res) => {
  try {
    const metodosPago = await MetodoPago.find().sort({ createdAt: -1 });

    res.status(200).json({
      cantidad: metodosPago.length,
      metodosPago: metodosPago,
    });
  } catch (error) {
    console.error("Error en API al consultar métodos de pago:", error);

    res.status(500).json({
      mensaje: "No fue posible consultar los métodos de pago.",
    });
  }
};

// API: registrar un método de pago
const crearMetodoPagoApi = async (req, res) => {
  try {
    const nuevoMetodoPago = new MetodoPago({
      nombre: req.body.nombre,
    });

    const metodoPagoGuardado = await nuevoMetodoPago.save();

    res.status(201).json({
      mensaje: "Método de pago registrado correctamente.",
      metodoPago: metodoPagoGuardado,
    });
  } catch (error) {
    console.error("Error en API al registrar método de pago:", error);

    let mensaje = "No fue posible registrar el método de pago.";

    if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).json({
      mensaje: mensaje,
    });
  }
};

module.exports = {
  listarMetodosPago,
  mostrarFormularioNuevo,
  crearMetodoPago,
  mostrarFormularioEditar,
  actualizarMetodoPago,
  eliminarMetodoPago,
  listarMetodosPagoApi,
  crearMetodoPagoApi,
};