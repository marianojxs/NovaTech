const Compra = require("../models/Compra");
const Proveedor = require("../models/Proveedor");
const Producto = require("../models/Producto");
const Sucursal = require("../models/Sucursal");
const Usuario = require("../models/Usuario");
const { aplicarMovimiento, revertirMovimientosPorDocumento } = require("../services/inventoryService");

const obtenerCatalogos = async () => {
  const [proveedores, productos, sucursales, usuarios] = await Promise.all([
    Proveedor.find({ estado: "Activo" }).sort({ empresa: 1 }),
    Producto.find({ estado: { $ne: "Descontinuado" } }).sort({ nombre: 1 }),
    Sucursal.find().sort({ nombre: 1 }),
    Usuario.find().sort({ nombre: 1 }),
  ]);
  return { proveedores, productos, sucursales, usuarios };
};

const resolverReferencias = async (body) => {
  let proveedor = null;
  let producto = null;
  let sucursal = null;
  let usuario = null;

  if (body.proveedorId) proveedor = await Proveedor.findById(body.proveedorId);
  if (!proveedor && body.proveedor) proveedor = await Proveedor.findOne({ empresa: body.proveedor });

  if (body.productoId) producto = await Producto.findById(body.productoId);
  if (!producto && body.codigoProducto) producto = await Producto.findOne({ codigo: String(body.codigoProducto).toUpperCase() });

  if (body.sucursalId) sucursal = await Sucursal.findById(body.sucursalId);
  if (!sucursal && body.sucursal) sucursal = await Sucursal.findOne({ nombre: body.sucursal });

  if (body.usuarioId) usuario = await Usuario.findById(body.usuarioId);
  if (!usuario && body.registradoPor) usuario = await Usuario.findOne({ nombre: body.registradoPor });

  if (!proveedor) throw new Error("Seleccione un proveedor válido.");
  if (!producto) throw new Error("Seleccione un producto válido.");

  return { proveedor, producto, sucursal, usuario };
};

const construirDatosCompra = (body, refs) => {
  const cantidad = Number(body.cantidad);
  const precioUnitario = Number(body.precioUnitario);
  return {
    numeroCompra: body.numeroCompra,
    fecha: body.fecha,
    proveedorId: refs.proveedor._id,
    proveedor: refs.proveedor.empresa,
    productoId: refs.producto._id,
    codigoProducto: refs.producto.codigo,
    nombreProducto: refs.producto.nombre,
    cantidad,
    precioUnitario,
    total: cantidad * precioUnitario,
    estado: body.estado || "Registrada",
    sucursalId: refs.sucursal?._id,
    sucursal: refs.sucursal?.nombre || "",
    usuarioId: refs.usuario?._id,
    registradoPor: refs.usuario?.nombre || "",
  };
};

const listarCompras = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { numeroCompra: { $regex: buscar, $options: "i" } },
            { proveedor: { $regex: buscar, $options: "i" } },
            { nombreProducto: { $regex: buscar, $options: "i" } },
            { codigoProducto: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const compras = await Compra.find(filtro).sort({ fecha: -1 });
    res.render("compras/lista", { compras, buscar });
  } catch (error) {
    console.error("Error al consultar compras:", error);
    res.status(500).send("No fue posible consultar las compras.");
  }
};

const mostrarFormularioNuevo = async (req, res) => {
  res.render("compras/nuevo", {
    error: null,
    compra: {},
    ...(await obtenerCatalogos()),
  });
};

const crearCompra = async (req, res) => {
  let compraGuardada;
  try {
    const refs = await resolverReferencias(req.body);
    const datos = construirDatosCompra(req.body, refs);
    compraGuardada = await Compra.create(datos);

    if (compraGuardada.estado === "Recibida") {
      await aplicarMovimiento({
        productoId: refs.producto._id,
        tipo: "Entrada",
        cantidad: compraGuardada.cantidad,
        fecha: compraGuardada.fecha,
        origen: "Compra",
        referencia: compraGuardada.numeroCompra,
        documentoId: compraGuardada._id,
      });
    }

    res.redirect("/compras");
  } catch (error) {
    console.error("Error al registrar compra:", error);
    if (compraGuardada) {
      await revertirMovimientosPorDocumento(compraGuardada._id).catch(() => {});
      await Compra.findByIdAndDelete(compraGuardada._id).catch(() => {});
    }

    let mensaje = error.message || "No fue posible registrar la compra.";
    if (error.code === 11000) mensaje = "Ya existe una compra con ese número.";
    if (error.name === "ValidationError") mensaje = Object.values(error.errors).map((dato) => dato.message).join(" ");

    res.status(400).render("compras/nuevo", {
      error: mensaje,
      compra: req.body,
      ...(await obtenerCatalogos()),
    });
  }
};

const mostrarFormularioEditar = async (req, res) => {
  try {
    const compra = await Compra.findById(req.params.id);
    if (!compra) return res.status(404).send("Compra no encontrada.");
    res.render("compras/editar", {
      compra,
      error: null,
      ...(await obtenerCatalogos()),
    });
  } catch (error) {
    res.status(500).send("No fue posible consultar la compra.");
  }
};

const actualizarCompra = async (req, res) => {
  let compra;
  let datosAnteriores;
  try {
    compra = await Compra.findById(req.params.id);
    if (!compra) return res.status(404).send("Compra no encontrada.");

    datosAnteriores = compra.toObject();
    await revertirMovimientosPorDocumento(compra._id);

    const refs = await resolverReferencias(req.body);
    Object.assign(compra, construirDatosCompra(req.body, refs));
    await compra.save();

    if (compra.estado === "Recibida") {
      await aplicarMovimiento({
        productoId: refs.producto._id,
        tipo: "Entrada",
        cantidad: compra.cantidad,
        fecha: compra.fecha,
        origen: "Compra",
        referencia: compra.numeroCompra,
        documentoId: compra._id,
      });
    }

    res.redirect("/compras");
  } catch (error) {
    console.error("Error al actualizar compra:", error);

    // Intento de restauración de la compra anterior si el cambio falló.
    if (compra && datosAnteriores) {
      try {
        await revertirMovimientosPorDocumento(compra._id);
        Object.assign(compra, datosAnteriores);
        compra.isNew = false;
        await compra.save();
        if (datosAnteriores.estado === "Recibida" && datosAnteriores.productoId) {
          await aplicarMovimiento({
            productoId: datosAnteriores.productoId,
            tipo: "Entrada",
            cantidad: datosAnteriores.cantidad,
            fecha: datosAnteriores.fecha,
            origen: "Compra",
            referencia: datosAnteriores.numeroCompra,
            documentoId: compra._id,
          });
        }
      } catch (rollbackError) {
        console.error("No fue posible restaurar la compra anterior:", rollbackError);
      }
    }

    let mensaje = error.message || "No fue posible actualizar la compra.";
    if (error.code === 11000) mensaje = "Ya existe otra compra con ese número.";
    res.status(400).render("compras/editar", {
      error: mensaje,
      compra: { _id: req.params.id, ...req.body },
      ...(await obtenerCatalogos()),
    });
  }
};

const eliminarCompra = async (req, res) => {
  try {
    const compra = await Compra.findById(req.params.id);
    if (!compra) return res.status(404).send("Compra no encontrada.");
    await revertirMovimientosPorDocumento(compra._id);
    await Compra.findByIdAndDelete(compra._id);
    res.redirect("/compras");
  } catch (error) {
    console.error("Error al eliminar compra:", error);
    res.status(500).send(error.message || "No fue posible eliminar la compra.");
  }
};

const listarComprasApi = async (req, res) => {
  try {
    const compras = await Compra.find().sort({ fecha: -1 });
    res.status(200).json({ cantidad: compras.length, compras });
  } catch (error) {
    res.status(500).json({ mensaje: "No fue posible consultar las compras." });
  }
};

const crearCompraApi = async (req, res) => {
  let compraGuardada;
  try {
    const refs = await resolverReferencias(req.body);
    compraGuardada = await Compra.create(construirDatosCompra(req.body, refs));
    if (compraGuardada.estado === "Recibida") {
      await aplicarMovimiento({
        productoId: refs.producto._id,
        tipo: "Entrada",
        cantidad: compraGuardada.cantidad,
        fecha: compraGuardada.fecha,
        origen: "Compra",
        referencia: compraGuardada.numeroCompra,
        documentoId: compraGuardada._id,
      });
    }
    res.status(201).json({ mensaje: "Compra registrada correctamente.", compra: compraGuardada });
  } catch (error) {
    if (compraGuardada) {
      await revertirMovimientosPorDocumento(compraGuardada._id).catch(() => {});
      await Compra.findByIdAndDelete(compraGuardada._id).catch(() => {});
    }
    res.status(400).json({ mensaje: error.code === 11000 ? "Ya existe una compra con ese número." : error.message });
  }
};

module.exports = {
  listarCompras,
  mostrarFormularioNuevo,
  crearCompra,
  mostrarFormularioEditar,
  actualizarCompra,
  eliminarCompra,
  listarComprasApi,
  crearCompraApi,
};
