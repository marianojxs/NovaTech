const Usuario = require("../models/Usuario");
const Compra = require("../models/Compra");
const Venta = require("../models/Venta");

// Listar
const listarUsuarios = async (req, res) => {
  try {

    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {

      filtro = {
        $or: [
          { usuario: { $regex: buscar, $options: "i" } },
          { nombre: { $regex: buscar, $options: "i" } },
        ],
      };

    }

    const usuarios = await Usuario.find(filtro);

    res.render("usuarios/lista", {
      usuarios,
      buscar,
    });

  } catch (error) {

    console.error(error);

    res.status(500).send("No fue posible consultar los usuarios.");

  }
};

// Formulario nuevo
const mostrarFormularioNuevo = (req, res) => {

  res.render("usuarios/nuevo", {

    error: null,
    usuario: {},

  });

};

// Crear
const crearUsuario = async (req, res) => {

  try {

    const nuevoUsuario = new Usuario({

      usuario: req.body.usuario,
      nombre: req.body.nombre,
      rol: req.body.rol,

    });

    await nuevoUsuario.save();

    res.redirect("/usuarios");

  } catch (error) {

    let mensaje = "No fue posible registrar el usuario.";

    if (error.code === 11000) {

      mensaje = "El usuario ya existe.";

    }

    res.status(400).render("usuarios/nuevo", {

      error: mensaje,
      usuario: req.body,

    });

  }

};

// Formulario editar
const mostrarFormularioEditar = async (req, res) => {

  try {

    const usuario = await Usuario.findById(req.params.id);

    if (!usuario) {

      return res.status(404).send("Usuario no encontrado.");

    }

    res.render("usuarios/editar", {

      usuario,
      error: null,

    });

  } catch (error) {

    res.status(500).send("No fue posible consultar el usuario.");

  }

};

// Actualizar
const actualizarUsuario = async (req, res) => {

  try {

    const usuario = await Usuario.findByIdAndUpdate(

      req.params.id,

      {

        usuario: req.body.usuario,
        nombre: req.body.nombre,
        rol: req.body.rol,

      },

      {

        new: true,
        runValidators: true,

      }

    );

    if (!usuario) {

      return res.status(404).send("Usuario no encontrado.");

    }

    res.redirect("/usuarios");

  } catch (error) {

    const mensaje = error.code === 11000
      ? "Ya existe otro registro con ese nombre de usuario."
      : "No fue posible actualizar el usuario.";

    res.status(400).render("usuarios/editar", {

      error: mensaje,

      usuario: {

        _id: req.params.id,

        ...req.body,

      },

    });

  }

};

// Eliminar
const eliminarUsuario = async (req, res) => {

  try {

    const [compraAsociada, ventaAsociada] = await Promise.all([
      Compra.exists({ usuarioId: req.params.id }),
      Venta.exists({ usuarioId: req.params.id }),
    ]);
    if (compraAsociada || ventaAsociada) {
      return res.status(400).send(
        "No se puede eliminar el usuario porque aparece como responsable de compras o ventas."
      );
    }

    const usuario = await Usuario.findByIdAndDelete(req.params.id);

    if (!usuario) {

      return res.status(404).send("Usuario no encontrado.");

    }

    res.redirect("/usuarios");

  } catch (error) {

    res.status(500).send("No fue posible eliminar el usuario.");

  }

};

module.exports = {

  listarUsuarios,
  mostrarFormularioNuevo,
  crearUsuario,
  mostrarFormularioEditar,
  actualizarUsuario,
  eliminarUsuario,

};