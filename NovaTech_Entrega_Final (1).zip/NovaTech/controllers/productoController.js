const Producto = require("../models/Producto");
const Categoria = require("../models/Categoria");
const Inventario = require("../models/Inventario");
const Devolucion = require("../models/Devolucion");
const Venta = require("../models/Venta");
const Compra = require("../models/Compra");
const { aplicarMovimiento } = require("../services/inventoryService");

const obtenerCategorias = () => Categoria.find({ estado: "Activa" }).sort({ nombre: 1 });

const listarProductos = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { nombre: { $regex: buscar, $options: "i" } },
            { codigo: { $regex: buscar, $options: "i" } },
            { categoria: { $regex: buscar, $options: "i" } },
            { marca: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const productos = await Producto.find(filtro).sort({ createdAt: -1 });
    res.render("productos/lista", { productos, buscar });
  } catch (error) {
    console.error("Error al consultar productos:", error);
    res.status(500).send("No fue posible consultar los productos.");
  }
};

const mostrarFormularioNuevo = async (req, res) => {
  res.render("productos/nuevo", {
    error: null,
    producto: {},
    categorias: await obtenerCategorias(),
  });
};

const crearProducto = async (req, res) => {
  let productoGuardado;
  try {
    const categoria = await Categoria.findById(req.body.categoriaId);
    if (!categoria) throw new Error("Seleccione una categoría válida.");

    const stockInicial = Number(req.body.stock || 0);
    const nuevoProducto = new Producto({
      codigo: req.body.codigo,
      nombre: req.body.nombre,
      descripcion: req.body.descripcion,
      categoriaId: categoria._id,
      categoria: categoria.nombre,
      marca: req.body.marca,
      precio: Number(req.body.precio),
      stock: 0,
      estado: req.body.estado === "Descontinuado" ? "Descontinuado" : "Agotado",
    });

    productoGuardado = await nuevoProducto.save();

    if (stockInicial > 0) {
      await aplicarMovimiento({
        productoId: productoGuardado._id,
        tipo: "Entrada",
        cantidad: stockInicial,
        fecha: new Date(),
        origen: "Ajuste",
        referencia: "Stock inicial",
        documentoId: productoGuardado._id,
      });
    }

    res.redirect("/productos");
  } catch (error) {
    console.error("Error al registrar producto:", error);
    if (productoGuardado) await Producto.findByIdAndDelete(productoGuardado._id).catch(() => {});

    let mensaje = error.message || "No fue posible registrar el producto.";
    if (error.code === 11000) mensaje = "Ya existe un producto con ese código.";
    if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors).map((dato) => dato.message).join(" ");
    }

    res.status(400).render("productos/nuevo", {
      error: mensaje,
      producto: req.body,
      categorias: await obtenerCategorias(),
    });
  }
};

const mostrarFormularioEditar = async (req, res) => {
  try {
    const producto = await Producto.findById(req.params.id);
    if (!producto) return res.status(404).send("Producto no encontrado.");

    res.render("productos/editar", {
      producto,
      error: null,
      categorias: await obtenerCategorias(),
    });
  } catch (error) {
    console.error("Error al consultar producto:", error);
    res.status(500).send("No fue posible consultar el producto.");
  }
};

const actualizarProducto = async (req, res) => {
  try {
    const categoria = await Categoria.findById(req.body.categoriaId);
    if (!categoria) throw new Error("Seleccione una categoría válida.");

    const productoActual = await Producto.findById(req.params.id);
    if (!productoActual) return res.status(404).send("Producto no encontrado.");
    const estadoDerivado = req.body.estado === "Descontinuado"
      ? "Descontinuado"
      : (productoActual.stock > 0 ? "Disponible" : "Agotado");

    const productoActualizado = await Producto.findByIdAndUpdate(
      req.params.id,
      {
        codigo: req.body.codigo,
        nombre: req.body.nombre,
        descripcion: req.body.descripcion,
        categoriaId: categoria._id,
        categoria: categoria.nombre,
        marca: req.body.marca,
        precio: Number(req.body.precio),
        estado: estadoDerivado,
      },
      { new: true, runValidators: true }
    );

    if (!productoActualizado) return res.status(404).send("Producto no encontrado.");
    res.redirect("/productos");
  } catch (error) {
    console.error("Error al actualizar producto:", error);
    let mensaje = error.message || "No fue posible actualizar el producto.";
    if (error.code === 11000) mensaje = "Ya existe otro producto con ese código.";
    if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors).map((dato) => dato.message).join(" ");
    }

    res.status(400).render("productos/editar", {
      error: mensaje,
      producto: { _id: req.params.id, ...req.body },
      categorias: await obtenerCategorias(),
    });
  }
};

const eliminarProducto = async (req, res) => {
  try {
    const producto = await Producto.findById(req.params.id);
    if (!producto) return res.status(404).send("Producto no encontrado.");
    if (producto.stock > 0) {
      return res.status(400).send("No se puede eliminar un producto con stock. Ajuste el inventario a cero o márquelo como descontinuado.");
    }

    const [compra, venta, devolucion, movimiento] = await Promise.all([
      Compra.exists({ productoId: producto._id }),
      Venta.exists({ productoId: producto._id }),
      Devolucion.exists({ productoId: producto._id }),
      Inventario.exists({ productoId: producto._id }),
    ]);
    if (compra || venta || devolucion || movimiento) {
      return res.status(400).send(
        "No se puede eliminar el producto porque tiene historial comercial o de inventario. Márquelo como Descontinuado."
      );
    }

    await Producto.findByIdAndDelete(req.params.id);
    res.redirect("/productos");
  } catch (error) {
    console.error("Error al eliminar producto:", error);
    res.status(500).send("No fue posible eliminar el producto.");
  }
};

const listarProductosApi = async (req, res) => {
  try {
    const productos = await Producto.find().sort({ createdAt: -1 });
    res.status(200).json({ cantidad: productos.length, productos });
  } catch (error) {
    res.status(500).json({ mensaje: "No fue posible consultar los productos." });
  }
};

const crearProductoApi = async (req, res) => {
  let productoGuardado;
  try {
    let categoria = null;
    if (req.body.categoriaId) categoria = await Categoria.findById(req.body.categoriaId);
    if (!categoria && req.body.categoria) categoria = await Categoria.findOne({ nombre: req.body.categoria });
    if (!categoria) throw new Error("La categoría indicada no existe.");

    const stockInicial = Number(req.body.stock || 0);
    productoGuardado = await Producto.create({
      codigo: req.body.codigo,
      nombre: req.body.nombre,
      descripcion: req.body.descripcion,
      categoriaId: categoria._id,
      categoria: categoria.nombre,
      marca: req.body.marca,
      precio: Number(req.body.precio),
      stock: 0,
      estado: req.body.estado === "Descontinuado" ? "Descontinuado" : "Agotado",
    });

    if (stockInicial > 0) {
      await aplicarMovimiento({
        productoId: productoGuardado._id,
        tipo: "Entrada",
        cantidad: stockInicial,
        origen: "Ajuste",
        referencia: "Stock inicial (API)",
        documentoId: productoGuardado._id,
      });
    }

    res.status(201).json({ mensaje: "Producto registrado correctamente.", producto: await Producto.findById(productoGuardado._id) });
  } catch (error) {
    if (productoGuardado) await Producto.findByIdAndDelete(productoGuardado._id).catch(() => {});
    res.status(400).json({ mensaje: error.code === 11000 ? "Ya existe un producto con ese código." : error.message });
  }
};

module.exports = {
  listarProductos,
  mostrarFormularioNuevo,
  crearProducto,
  mostrarFormularioEditar,
  actualizarProducto,
  eliminarProducto,
  listarProductosApi,
  crearProductoApi,
};
