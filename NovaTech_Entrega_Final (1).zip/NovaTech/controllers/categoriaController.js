const Categoria = require("../models/Categoria");
const Producto = require("../models/Producto");

// Mostrar categorías y realizar búsquedas
const listarCategorias = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";

    let filtro = {};

    if (buscar) {
      filtro = {
        $or: [
          { nombre: { $regex: buscar, $options: "i" } },
          { descripcion: { $regex: buscar, $options: "i" } },
        ],
      };
    }

    const categorias = await Categoria.find(filtro).sort({
      createdAt: -1,
    });

    res.render("categorias/lista", {
      categorias,
      buscar,
    });
  } catch (error) {
    console.error("Error al consultar categorías:", error);

    res.status(500).send(
      "No fue posible consultar las categorías."
    );
  }
};

// Mostrar formulario nuevo
const mostrarFormularioNuevo = (req, res) => {
  res.render("categorias/nuevo", {
    error: null,
    categoria: {},
  });
};

// Crear categoría
const crearCategoria = async (req, res) => {
  try {
    const nuevaCategoria = new Categoria({
      nombre: req.body.nombre,
      descripcion: req.body.descripcion,
      estado: req.body.estado,
    });

    await nuevaCategoria.save();

    res.redirect("/categorias");
  } catch (error) {
    console.error("Error al registrar categoría:", error);

    let mensaje = "No fue posible registrar la categoría.";

    if (error.code === 11000) {
      mensaje = "Ya existe una categoría con ese nombre.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("categorias/nuevo", {
      error: mensaje,
      categoria: req.body,
    });
  }
};

// Mostrar formulario editar
const mostrarFormularioEditar = async (req, res) => {
  try {
    const categoria = await Categoria.findById(req.params.id);

    if (!categoria) {
      return res.status(404).send("Categoría no encontrada.");
    }

    res.render("categorias/editar", {
      categoria,
      error: null,
    });
  } catch (error) {
    console.error("Error al consultar categoría:", error);

    res.status(500).send(
      "No fue posible consultar la categoría."
    );
  }
};

// Actualizar categoría
const actualizarCategoria = async (req, res) => {
  try {
    const categoriaActualizada =
      await Categoria.findByIdAndUpdate(
        req.params.id,
        {
          nombre: req.body.nombre,
          descripcion: req.body.descripcion,
          estado: req.body.estado,
        },
        {
          new: true,
          runValidators: true,
        }
      );

    if (!categoriaActualizada) {
      return res.status(404).send("Categoría no encontrada.");
    }

    // Mantiene sincronizado el nombre de categoría usado como snapshot en productos.
    await Producto.updateMany(
      { categoriaId: categoriaActualizada._id },
      { $set: { categoria: categoriaActualizada.nombre } }
    );

    res.redirect("/categorias");
  } catch (error) {
    console.error("Error al actualizar categoría:", error);

    let mensaje = "No fue posible actualizar la categoría.";

    if (error.code === 11000) {
      mensaje = "Ya existe otra categoría con ese nombre.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).render("categorias/editar", {
      error: mensaje,
      categoria: {
        _id: req.params.id,
        ...req.body,
      },
    });
  }
};

// Eliminar categoría
const eliminarCategoria = async (req, res) => {
  try {
    const enUso = await Producto.exists({ categoriaId: req.params.id });
    if (enUso) {
      return res.status(400).send(
        "No se puede eliminar la categoría porque está asociada a productos. Reasigne esos productos primero."
      );
    }

    const categoriaEliminada =
      await Categoria.findByIdAndDelete(req.params.id);

    if (!categoriaEliminada) {
      return res.status(404).send("Categoría no encontrada.");
    }

    res.redirect("/categorias");
  } catch (error) {
    console.error("Error al eliminar categoría:", error);

    res.status(500).send(
      "No fue posible eliminar la categoría."
    );
  }
};

// API GET
const listarCategoriasApi = async (req, res) => {
  try {
    const categorias = await Categoria.find().sort({
      createdAt: -1,
    });

    res.status(200).json({
      cantidad: categorias.length,
      categorias,
    });
  } catch (error) {
    res.status(500).json({
      mensaje: "No fue posible consultar las categorías.",
    });
  }
};

// API POST
const crearCategoriaApi = async (req, res) => {
  try {
    const categoria = new Categoria({
      nombre: req.body.nombre,
      descripcion: req.body.descripcion,
      estado: req.body.estado || "Activa",
    });

    const categoriaGuardada = await categoria.save();

    res.status(201).json({
      mensaje: "Categoría registrada correctamente.",
      categoria: categoriaGuardada,
    });
  } catch (error) {
    let mensaje = "No fue posible registrar la categoría.";

    if (error.code === 11000) {
      mensaje = "Ya existe una categoría con ese nombre.";
    } else if (error.name === "ValidationError") {
      mensaje = Object.values(error.errors)
        .map((dato) => dato.message)
        .join(" ");
    }

    res.status(400).json({
      mensaje,
    });
  }
};

module.exports = {
  listarCategorias,
  mostrarFormularioNuevo,
  crearCategoria,
  mostrarFormularioEditar,
  actualizarCategoria,
  eliminarCategoria,
  listarCategoriasApi,
  crearCategoriaApi,
};