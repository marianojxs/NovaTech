const DetalleVenta = require("../models/DetalleVenta");

const listarDetallesVenta = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { numeroVenta: { $regex: buscar, $options: "i" } },
            { cliente: { $regex: buscar, $options: "i" } },
            { codigoProducto: { $regex: buscar, $options: "i" } },
            { nombreProducto: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const detalles = await DetalleVenta.find(filtro).sort({ fechaVenta: -1 });
    res.render("detalleVentas/lista", { detalles, buscar });
  } catch (error) {
    console.error("Error al consultar detalle de ventas:", error);
    res.status(500).send("No fue posible consultar los detalles de venta.");
  }
};

const listarDetallesVentaApi = async (req, res) => {
  try {
    const detalles = await DetalleVenta.find().sort({ fechaVenta: -1 });
    res.status(200).json({ cantidad: detalles.length, detalles });
  } catch (error) {
    res.status(500).json({ mensaje: "No fue posible consultar los detalles de venta." });
  }
};

module.exports = { listarDetallesVenta, listarDetallesVentaApi };
