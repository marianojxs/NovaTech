const Inventario = require("../models/Inventario");
const Producto = require("../models/Producto");
const { aplicarMovimiento, revertirMovimiento } = require("../services/inventoryService");

const obtenerProductos = () => Producto.find({ estado: { $ne: "Descontinuado" } }).sort({ nombre: 1 });

const listarInventario = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { producto: { $regex: buscar, $options: "i" } },
            { codigoProducto: { $regex: buscar, $options: "i" } },
            { referencia: { $regex: buscar, $options: "i" } },
            { origen: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const inventario = await Inventario.find(filtro).sort({ fecha: -1, createdAt: -1 });
    res.render("inventario/lista", { inventario, buscar });
  } catch (error) {
    console.error("Error al consultar inventario:", error);
    res.status(500).send("No fue posible consultar el inventario.");
  }
};

const mostrarFormularioNuevo = async (req, res) => {
  res.render("inventario/nuevo", {
    error: null,
    movimiento: {},
    productos: await obtenerProductos(),
  });
};

const crearInventario = async (req, res) => {
  try {
    await aplicarMovimiento({
      productoId: req.body.productoId,
      tipo: req.body.tipo,
      cantidad: req.body.cantidad,
      fecha: req.body.fecha,
      origen: "Ajuste",
      referencia: req.body.referencia || "Ajuste manual",
    });
    res.redirect("/inventario");
  } catch (error) {
    res.status(400).render("inventario/nuevo", {
      error: error.message,
      movimiento: req.body,
      productos: await obtenerProductos(),
    });
  }
};

const mostrarFormularioEditar = async (req, res) => {
  try {
    const movimiento = await Inventario.findById(req.params.id);
    if (!movimiento) return res.status(404).send("Movimiento no encontrado.");
    if (movimiento.origen !== "Ajuste") {
      return res.status(400).send("Los movimientos automáticos se modifican desde su compra, venta o devolución de origen.");
    }
    res.render("inventario/editar", {
      movimiento,
      error: null,
      productos: await obtenerProductos(),
    });
  } catch (error) {
    res.status(500).send("No fue posible consultar el movimiento.");
  }
};

const actualizarInventario = async (req, res) => {
  let movimiento;
  let anterior;
  try {
    movimiento = await Inventario.findById(req.params.id);
    if (!movimiento) return res.status(404).send("Movimiento no encontrado.");
    if (movimiento.origen !== "Ajuste") return res.status(400).send("Solo se pueden editar ajustes manuales.");

    anterior = movimiento.toObject();
    await revertirMovimiento(movimiento);

    await aplicarMovimiento({
      productoId: req.body.productoId,
      tipo: req.body.tipo,
      cantidad: req.body.cantidad,
      fecha: req.body.fecha,
      origen: "Ajuste",
      referencia: req.body.referencia || "Ajuste manual",
    });

    res.redirect("/inventario");
  } catch (error) {
    console.error("Error al actualizar inventario:", error);
    // Si ya se revirtió y la nueva operación falló, intentamos restaurar el ajuste anterior.
    if (anterior?.productoId) {
      await aplicarMovimiento({
        productoId: anterior.productoId,
        tipo: anterior.tipo,
        cantidad: anterior.cantidad,
        fecha: anterior.fecha,
        origen: "Ajuste",
        referencia: anterior.referencia,
      }).catch(() => {});
    }
    res.status(400).render("inventario/editar", {
      error: error.message,
      movimiento: { _id: req.params.id, ...req.body },
      productos: await obtenerProductos(),
    });
  }
};

const eliminarInventario = async (req, res) => {
  try {
    const movimiento = await Inventario.findById(req.params.id);
    if (!movimiento) return res.status(404).send("Movimiento no encontrado.");
    if (movimiento.origen !== "Ajuste") return res.status(400).send("Los movimientos automáticos se eliminan desde su documento de origen.");
    await revertirMovimiento(movimiento);
    res.redirect("/inventario");
  } catch (error) {
    res.status(500).send(error.message || "No fue posible eliminar el movimiento.");
  }
};

const listarInventarioApi = async (req, res) => {
  try {
    const inventario = await Inventario.find().sort({ fecha: -1 });
    res.status(200).json({ cantidad: inventario.length, inventario });
  } catch (error) {
    res.status(500).json({ mensaje: "Error al consultar inventario" });
  }
};

const crearInventarioApi = async (req, res) => {
  try {
    let producto = null;
    if (req.body.productoId) producto = await Producto.findById(req.body.productoId);
    if (!producto && req.body.codigoProducto) {
      producto = await Producto.findOne({ codigo: String(req.body.codigoProducto).toUpperCase() });
    }
    if (!producto) throw new Error("Indique un producto válido mediante productoId o codigoProducto.");

    const movimiento = await aplicarMovimiento({
      productoId: producto._id,
      tipo: req.body.tipo,
      cantidad: req.body.cantidad,
      fecha: req.body.fecha || new Date(),
      origen: "Ajuste",
      referencia: req.body.referencia || "Ajuste API",
    });
    res.status(201).json({ mensaje: "Movimiento registrado", movimiento });
  } catch (error) {
    res.status(400).json({ mensaje: error.message });
  }
};

module.exports = {
  listarInventario,
  mostrarFormularioNuevo,
  crearInventario,
  mostrarFormularioEditar,
  actualizarInventario,
  eliminarInventario,
  listarInventarioApi,
  crearInventarioApi,
};
