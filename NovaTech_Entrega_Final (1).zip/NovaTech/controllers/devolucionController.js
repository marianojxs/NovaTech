const Devolucion = require("../models/Devolucion");
const Venta = require("../models/Venta");
const { aplicarMovimiento, revertirMovimientosPorDocumento } = require("../services/inventoryService");

const obtenerVentas = () => Venta.find({ estado: "Facturada" }).sort({ fecha: -1, createdAt: -1 });

const validarCantidadDevuelta = async (venta, cantidad, excluirId = null) => {
  const filtro = { ventaId: venta._id };
  if (excluirId) filtro._id = { $ne: excluirId };

  // find() permite que Mongoose convierta correctamente los ObjectId del filtro.
  const devolucionesPrevias = await Devolucion.find(filtro).select("cantidad");
  const yaDevuelto = devolucionesPrevias.reduce(
    (total, devolucion) => total + Number(devolucion.cantidad || 0),
    0
  );

  if (yaDevuelto + cantidad > venta.cantidad) {
    throw new Error(
      `La cantidad excede lo vendido. Vendido: ${venta.cantidad}; ya devuelto: ${yaDevuelto}.`
    );
  }
};

const inicio = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { numero: { $regex: buscar, $options: "i" } },
            { factura: { $regex: buscar, $options: "i" } },
            { cliente: { $regex: buscar, $options: "i" } },
            { producto: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const devoluciones = await Devolucion.find(filtro).sort({ fecha: -1 });
    res.render("devoluciones/inicio", { devoluciones, buscar });
  } catch (error) {
    console.error("Error al cargar devoluciones:", error);
    res.status(500).send("Error al cargar las devoluciones.");
  }
};

const nuevo = async (req, res) => {
  res.render("devoluciones/nuevo", {
    error: null,
    devolucion: {},
    ventas: await obtenerVentas(),
  });
};

const guardar = async (req, res) => {
  let devolucionGuardada;
  try {
    const venta = await Venta.findById(req.body.ventaId);
    if (!venta) throw new Error("Seleccione una venta válida.");

    const cantidad = Number(req.body.cantidad);
    if (!Number.isFinite(cantidad) || cantidad <= 0) throw new Error("La cantidad debe ser mayor que cero.");
    await validarCantidadDevuelta(venta, cantidad);

    devolucionGuardada = await Devolucion.create({
      numero: req.body.numero,
      ventaId: venta._id,
      factura: venta.factura,
      clienteId: venta.clienteId,
      cliente: venta.cliente,
      productoId: venta.productoId,
      codigoProducto: venta.codigoProducto,
      producto: venta.nombreProducto,
      cantidad,
      motivo: req.body.motivo,
      fecha: req.body.fecha,
    });

    await aplicarMovimiento({
      productoId: venta.productoId,
      tipo: "Entrada",
      cantidad,
      fecha: devolucionGuardada.fecha,
      origen: "Devolución",
      referencia: devolucionGuardada.numero,
      documentoId: devolucionGuardada._id,
    });

    res.redirect("/devoluciones");
  } catch (error) {
    console.error("Error al guardar devolución:", error);
    if (devolucionGuardada) {
      await revertirMovimientosPorDocumento(devolucionGuardada._id).catch(() => {});
      await Devolucion.findByIdAndDelete(devolucionGuardada._id).catch(() => {});
    }

    const mensaje = error.code === 11000 ? "Ya existe una devolución con ese número." : error.message;
    res.status(400).render("devoluciones/nuevo", {
      error: mensaje,
      devolucion: req.body,
      ventas: await obtenerVentas(),
    });
  }
};

const editar = async (req, res) => {
  try {
    const devolucion = await Devolucion.findById(req.params.id);
    if (!devolucion) return res.status(404).send("Devolución no encontrada.");
    res.render("devoluciones/editar", {
      devolucion,
      error: null,
      ventas: await obtenerVentas(),
    });
  } catch (error) {
    res.status(500).send("Error al cargar la devolución.");
  }
};

const actualizar = async (req, res) => {
  let devolucion;
  let anterior;
  try {
    devolucion = await Devolucion.findById(req.params.id);
    if (!devolucion) return res.status(404).send("Devolución no encontrada.");
    anterior = devolucion.toObject();

    await revertirMovimientosPorDocumento(devolucion._id);

    const venta = await Venta.findById(req.body.ventaId);
    if (!venta) throw new Error("Seleccione una venta válida.");
    const cantidad = Number(req.body.cantidad);
    await validarCantidadDevuelta(venta, cantidad, devolucion._id);

    Object.assign(devolucion, {
      numero: req.body.numero,
      ventaId: venta._id,
      factura: venta.factura,
      clienteId: venta.clienteId,
      cliente: venta.cliente,
      productoId: venta.productoId,
      codigoProducto: venta.codigoProducto,
      producto: venta.nombreProducto,
      cantidad,
      motivo: req.body.motivo,
      fecha: req.body.fecha,
    });
    await devolucion.save();

    await aplicarMovimiento({
      productoId: venta.productoId,
      tipo: "Entrada",
      cantidad,
      fecha: devolucion.fecha,
      origen: "Devolución",
      referencia: devolucion.numero,
      documentoId: devolucion._id,
    });

    res.redirect("/devoluciones");
  } catch (error) {
    console.error("Error al actualizar devolución:", error);
    if (devolucion && anterior) {
      try {
        await revertirMovimientosPorDocumento(devolucion._id);
        Object.assign(devolucion, anterior);
        devolucion.isNew = false;
        await devolucion.save();
        if (anterior.productoId) {
          await aplicarMovimiento({
            productoId: anterior.productoId,
            tipo: "Entrada",
            cantidad: anterior.cantidad,
            fecha: anterior.fecha,
            origen: "Devolución",
            referencia: anterior.numero,
            documentoId: devolucion._id,
          });
        }
      } catch (rollbackError) {
        console.error("No fue posible restaurar la devolución anterior:", rollbackError);
      }
    }

    res.status(400).render("devoluciones/editar", {
      error: error.code === 11000 ? "Ya existe una devolución con ese número." : error.message,
      devolucion: { _id: req.params.id, ...req.body },
      ventas: await obtenerVentas(),
    });
  }
};

const eliminar = async (req, res) => {
  try {
    const devolucion = await Devolucion.findById(req.params.id);
    if (!devolucion) return res.status(404).send("Devolución no encontrada.");
    await revertirMovimientosPorDocumento(devolucion._id);
    await Devolucion.findByIdAndDelete(devolucion._id);
    res.redirect("/devoluciones");
  } catch (error) {
    console.error("Error al eliminar devolución:", error);
    res.status(500).send(error.message || "Error al eliminar la devolución.");
  }
};

module.exports = { inicio, nuevo, guardar, editar, actualizar, eliminar };
