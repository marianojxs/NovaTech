const Venta = require("../models/Venta");
const DetalleVenta = require("../models/DetalleVenta");
const Devolucion = require("../models/Devolucion");
const Cliente = require("../models/Cliente");
const Producto = require("../models/Producto");
const MetodoPago = require("../models/MetodoPago");
const Sucursal = require("../models/Sucursal");
const Usuario = require("../models/Usuario");
const { aplicarMovimiento, revertirMovimientosPorDocumento } = require("../services/inventoryService");

const obtenerCatalogos = async () => {
  const [clientes, productos, metodosPago, sucursales, usuarios] = await Promise.all([
    Cliente.find({ estado: "Activo" }).sort({ nombre: 1 }),
    Producto.find({ estado: { $ne: "Descontinuado" } }).sort({ nombre: 1 }),
    MetodoPago.find().sort({ nombre: 1 }),
    Sucursal.find().sort({ nombre: 1 }),
    Usuario.find().sort({ nombre: 1 }),
  ]);
  return { clientes, productos, metodosPago, sucursales, usuarios };
};

const resolverReferencias = async (body) => {
  let cliente = null;
  let producto = null;
  let metodoPago = null;
  let sucursal = null;
  let usuario = null;

  if (body.clienteId) cliente = await Cliente.findById(body.clienteId);
  if (!cliente && body.cliente) cliente = await Cliente.findOne({ nombre: body.cliente });

  if (body.productoId) producto = await Producto.findById(body.productoId);
  if (!producto && body.codigoProducto) producto = await Producto.findOne({ codigo: String(body.codigoProducto).toUpperCase() });

  if (body.metodoPagoId) metodoPago = await MetodoPago.findById(body.metodoPagoId);
  if (!metodoPago && body.metodoPago) metodoPago = await MetodoPago.findOne({ nombre: body.metodoPago });

  if (body.sucursalId) sucursal = await Sucursal.findById(body.sucursalId);
  if (!sucursal && body.sucursal) sucursal = await Sucursal.findOne({ nombre: body.sucursal });

  if (body.usuarioId) usuario = await Usuario.findById(body.usuarioId);
  if (!usuario && body.registradoPor) usuario = await Usuario.findOne({ nombre: body.registradoPor });

  if (!cliente) throw new Error("Seleccione un cliente válido.");
  if (!producto) throw new Error("Seleccione un producto válido.");
  if (!metodoPago) throw new Error("Seleccione un método de pago válido.");

  return { cliente, producto, metodoPago, sucursal, usuario };
};

const construirDatosVenta = (body, refs) => {
  const cantidad = Number(body.cantidad);
  const precioUnitario = Number(refs.producto.precio);
  return {
    factura: body.factura,
    clienteId: refs.cliente._id,
    cliente: refs.cliente.nombre,
    fecha: body.fecha,
    productoId: refs.producto._id,
    codigoProducto: refs.producto.codigo,
    nombreProducto: refs.producto.nombre,
    cantidad,
    precioUnitario,
    total: cantidad * precioUnitario,
    metodoPagoId: refs.metodoPago._id,
    metodoPago: refs.metodoPago.nombre,
    sucursalId: refs.sucursal?._id,
    sucursal: refs.sucursal?.nombre || "",
    usuarioId: refs.usuario?._id,
    registradoPor: refs.usuario?.nombre || "",
    estado: "Facturada",
  };
};

const datosDetalleDesdeVenta = (venta) => ({
  ventaId: venta._id,
  clienteId: venta.clienteId,
  productoId: venta.productoId,
  numeroVenta: venta.factura,
  fechaVenta: venta.fecha,
  cliente: venta.cliente,
  codigoProducto: venta.codigoProducto,
  nombreProducto: venta.nombreProducto,
  cantidad: venta.cantidad,
  precioUnitario: venta.precioUnitario,
  subtotal: venta.total,
  estado: venta.estado === "Anulada" ? "Cancelada" : "Facturada",
});

const listarVentas = async (req, res) => {
  try {
    const buscar = req.query.buscar || "";
    const filtro = buscar
      ? {
          $or: [
            { factura: { $regex: buscar, $options: "i" } },
            { cliente: { $regex: buscar, $options: "i" } },
            { codigoProducto: { $regex: buscar, $options: "i" } },
            { nombreProducto: { $regex: buscar, $options: "i" } },
          ],
        }
      : {};

    const ventas = await Venta.find(filtro).sort({ fecha: -1, createdAt: -1 });
    res.render("ventas/lista", { ventas, buscar });
  } catch (error) {
    console.error("Error al consultar ventas:", error);
    res.status(500).send("No fue posible consultar las ventas.");
  }
};

const mostrarFormularioNuevo = async (req, res) => {
  res.render("ventas/nuevo", {
    error: null,
    venta: {},
    ...(await obtenerCatalogos()),
  });
};

const crearVenta = async (req, res) => {
  let ventaGuardada;
  try {
    const refs = await resolverReferencias(req.body);
    const datos = construirDatosVenta(req.body, refs);

    if (!Number.isFinite(datos.cantidad) || datos.cantidad <= 0) {
      throw new Error("La cantidad debe ser mayor que cero.");
    }
    if (refs.producto.stock < datos.cantidad) {
      throw new Error(`Stock insuficiente. Disponible: ${refs.producto.stock}.`);
    }

    ventaGuardada = await Venta.create(datos);

    await aplicarMovimiento({
      productoId: refs.producto._id,
      tipo: "Salida",
      cantidad: ventaGuardada.cantidad,
      fecha: ventaGuardada.fecha,
      origen: "Venta",
      referencia: ventaGuardada.factura,
      documentoId: ventaGuardada._id,
    });

    await DetalleVenta.create(datosDetalleDesdeVenta(ventaGuardada));
    res.redirect("/ventas");
  } catch (error) {
    console.error("Error al registrar venta:", error);
    if (ventaGuardada) {
      await DetalleVenta.deleteMany({ ventaId: ventaGuardada._id }).catch(() => {});
      await revertirMovimientosPorDocumento(ventaGuardada._id).catch(() => {});
      await Venta.findByIdAndDelete(ventaGuardada._id).catch(() => {});
    }

    let mensaje = error.message || "No fue posible registrar la venta.";
    if (error.code === 11000) mensaje = "Ya existe una venta con ese número de factura.";
    if (error.name === "ValidationError") mensaje = Object.values(error.errors).map((dato) => dato.message).join(" ");

    res.status(400).render("ventas/nuevo", {
      error: mensaje,
      venta: req.body,
      ...(await obtenerCatalogos()),
    });
  }
};

const mostrarFormularioEditar = async (req, res) => {
  try {
    const venta = await Venta.findById(req.params.id);
    if (!venta) return res.status(404).send("Venta no encontrada.");
    res.render("ventas/editar", {
      venta,
      error: null,
      ...(await obtenerCatalogos()),
    });
  } catch (error) {
    res.status(500).send("No fue posible cargar la venta.");
  }
};

const actualizarVenta = async (req, res) => {
  let venta;
  let datosAnteriores;
  try {
    venta = await Venta.findById(req.params.id);
    if (!venta) return res.status(404).send("Venta no encontrada.");

    const tieneDevoluciones = await Devolucion.exists({ ventaId: venta._id });
    if (tieneDevoluciones) {
      throw new Error(
        "No se puede modificar una venta que ya tiene devoluciones asociadas. Elimine o ajuste primero esas devoluciones."
      );
    }

    datosAnteriores = venta.toObject();
    await revertirMovimientosPorDocumento(venta._id);

    const refs = await resolverReferencias(req.body);
    const datos = construirDatosVenta(req.body, refs);
    if (refs.producto.stock < datos.cantidad) {
      throw new Error(`Stock insuficiente. Disponible: ${refs.producto.stock}.`);
    }

    Object.assign(venta, datos);
    await venta.save();

    await aplicarMovimiento({
      productoId: refs.producto._id,
      tipo: "Salida",
      cantidad: venta.cantidad,
      fecha: venta.fecha,
      origen: "Venta",
      referencia: venta.factura,
      documentoId: venta._id,
    });

    await DetalleVenta.findOneAndUpdate(
      { $or: [{ ventaId: venta._id }, { numeroVenta: datosAnteriores.factura }] },
      datosDetalleDesdeVenta(venta),
      { upsert: true, new: true, runValidators: true }
    );

    res.redirect("/ventas");
  } catch (error) {
    console.error("Error al actualizar venta:", error);

    if (venta && datosAnteriores) {
      try {
        await revertirMovimientosPorDocumento(venta._id);
        Object.assign(venta, datosAnteriores);
        venta.isNew = false;
        await venta.save();
        if (datosAnteriores.productoId) {
          await aplicarMovimiento({
            productoId: datosAnteriores.productoId,
            tipo: "Salida",
            cantidad: datosAnteriores.cantidad,
            fecha: datosAnteriores.fecha,
            origen: "Venta",
            referencia: datosAnteriores.factura,
            documentoId: venta._id,
          });
        }
        await DetalleVenta.findOneAndUpdate(
          { $or: [{ ventaId: venta._id }, { numeroVenta: datosAnteriores.factura }] },
          datosDetalleDesdeVenta(venta),
          { upsert: true, new: true, runValidators: true }
        );
      } catch (rollbackError) {
        console.error("No fue posible restaurar la venta anterior:", rollbackError);
      }
    }

    let mensaje = error.message || "No fue posible actualizar la venta.";
    if (error.code === 11000) mensaje = "Ya existe otra venta con ese número de factura.";
    res.status(400).render("ventas/editar", {
      error: mensaje,
      venta: { _id: req.params.id, ...req.body },
      ...(await obtenerCatalogos()),
    });
  }
};

const eliminarVenta = async (req, res) => {
  try {
    const venta = await Venta.findById(req.params.id);
    if (!venta) return res.status(404).send("Venta no encontrada.");

    const tieneDevoluciones = await Devolucion.exists({ ventaId: venta._id });
    if (tieneDevoluciones) {
      return res.status(400).send(
        "No se puede eliminar la venta porque tiene devoluciones asociadas. Elimine primero esas devoluciones."
      );
    }

    await revertirMovimientosPorDocumento(venta._id);
    await DetalleVenta.deleteMany({ $or: [{ ventaId: venta._id }, { numeroVenta: venta.factura }] });
    await Venta.findByIdAndDelete(venta._id);
    res.redirect("/ventas");
  } catch (error) {
    console.error("Error al eliminar venta:", error);
    res.status(500).send(error.message || "No fue posible eliminar la venta.");
  }
};

const listarVentasApi = async (req, res) => {
  try {
    const ventas = await Venta.find().sort({ fecha: -1 });
    res.status(200).json({ cantidad: ventas.length, ventas });
  } catch (error) {
    res.status(500).json({ mensaje: "No fue posible consultar las ventas." });
  }
};

const crearVentaApi = async (req, res) => {
  let ventaGuardada;
  try {
    const refs = await resolverReferencias(req.body);
    const datos = construirDatosVenta(req.body, refs);
    if (!Number.isFinite(datos.cantidad) || datos.cantidad <= 0) {
      throw new Error("La cantidad debe ser mayor que cero.");
    }
    if (refs.producto.stock < datos.cantidad) throw new Error(`Stock insuficiente. Disponible: ${refs.producto.stock}.`);

    ventaGuardada = await Venta.create(datos);
    await aplicarMovimiento({
      productoId: refs.producto._id,
      tipo: "Salida",
      cantidad: ventaGuardada.cantidad,
      fecha: ventaGuardada.fecha,
      origen: "Venta",
      referencia: ventaGuardada.factura,
      documentoId: ventaGuardada._id,
    });
    await DetalleVenta.create(datosDetalleDesdeVenta(ventaGuardada));
    res.status(201).json({ mensaje: "Venta y detalle registrados correctamente.", venta: ventaGuardada });
  } catch (error) {
    if (ventaGuardada) {
      await DetalleVenta.deleteMany({ ventaId: ventaGuardada._id }).catch(() => {});
      await revertirMovimientosPorDocumento(ventaGuardada._id).catch(() => {});
      await Venta.findByIdAndDelete(ventaGuardada._id).catch(() => {});
    }
    res.status(400).json({ mensaje: error.code === 11000 ? "Ya existe esa factura." : error.message });
  }
};

module.exports = {
  listarVentas,
  mostrarFormularioNuevo,
  crearVenta,
  mostrarFormularioEditar,
  actualizarVenta,
  eliminarVenta,
  listarVentasApi,
  crearVentaApi,
};
