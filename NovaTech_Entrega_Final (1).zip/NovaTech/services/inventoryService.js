const Inventario = require("../models/Inventario");
const Producto = require("../models/Producto");

const actualizarEstadoProducto = (producto) => {
  if (producto.estado === "Descontinuado") return;
  producto.estado = producto.stock > 0 ? "Disponible" : "Agotado";
};

const obtenerProducto = async (productoId) => {
  const producto = await Producto.findById(productoId);
  if (!producto) {
    const error = new Error("El producto seleccionado no existe.");
    error.status = 400;
    throw error;
  }
  return producto;
};

const aplicarMovimiento = async ({
  productoId,
  tipo,
  cantidad,
  fecha = new Date(),
  origen = "Ajuste",
  referencia = "",
  documentoId,
}) => {
  const producto = await obtenerProducto(productoId);
  const cantidadNumero = Number(cantidad);

  if (!["Entrada", "Salida"].includes(tipo)) {
    const error = new Error("El tipo de movimiento debe ser Entrada o Salida.");
    error.status = 400;
    throw error;
  }

  if (!Number.isFinite(cantidadNumero) || cantidadNumero <= 0) {
    const error = new Error("La cantidad del movimiento debe ser mayor que cero.");
    error.status = 400;
    throw error;
  }

  if (tipo === "Salida" && producto.stock < cantidadNumero) {
    const error = new Error(
      `Stock insuficiente para ${producto.nombre}. Disponible: ${producto.stock}.`
    );
    error.status = 400;
    throw error;
  }

  const delta = tipo === "Entrada" ? cantidadNumero : -cantidadNumero;
  producto.stock += delta;
  actualizarEstadoProducto(producto);
  await producto.save();

  try {
    return await Inventario.create({
      productoId: producto._id,
      codigoProducto: producto.codigo,
      producto: producto.nombre,
      tipo,
      cantidad: cantidadNumero,
      fecha,
      origen,
      referencia,
      documentoId,
    });
  } catch (error) {
    // Rollback simple para mantener stock y movimiento sincronizados.
    producto.stock -= delta;
    actualizarEstadoProducto(producto);
    await producto.save();
    throw error;
  }
};

const revertirMovimiento = async (movimiento) => {
  if (movimiento.productoId) {
    const producto = await Producto.findById(movimiento.productoId);
    if (producto) {
      const delta = movimiento.tipo === "Entrada"
        ? -movimiento.cantidad
        : movimiento.cantidad;

      const nuevoStock = producto.stock + delta;
      if (nuevoStock < 0) {
        const error = new Error(
          `No se puede revertir el movimiento porque el stock de ${producto.nombre} quedaría negativo.`
        );
        error.status = 400;
        throw error;
      }

      producto.stock = nuevoStock;
      actualizarEstadoProducto(producto);
      await producto.save();
    }
  }

  await Inventario.findByIdAndDelete(movimiento._id);
};

const revertirMovimientosPorDocumento = async (documentoId) => {
  if (!documentoId) return;
  const movimientos = await Inventario.find({ documentoId }).sort({ createdAt: -1 });
  for (const movimiento of movimientos) {
    await revertirMovimiento(movimiento);
  }
};

module.exports = {
  aplicarMovimiento,
  revertirMovimiento,
  revertirMovimientosPorDocumento,
};
