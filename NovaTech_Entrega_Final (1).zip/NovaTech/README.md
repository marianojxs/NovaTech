# NovaTech Solutions — Sistema de ventas e inventario NoSQL

Proyecto final desarrollado para el curso **Base de Datos NoSQL**. La solución centraliza procesos comerciales de una empresa tecnológica ficticia mediante **Node.js, Express, EJS, MongoDB y Mongoose**, aplicando un diseño documental con referencias, validaciones, índices y reglas de negocio integradas.

## Funcionalidades principales

- Dashboard con métricas operativas, ventas recientes, alertas de stock y movimientos de inventario.
- CRUD web para las 12 colecciones principales del proyecto.
- Persistencia en MongoDB mediante Mongoose.
- Búsquedas por texto y campos clave.
- Índices únicos y de texto en datos de consulta frecuente.
- API JSON para pruebas con Postman.
- Integración automática entre compras, ventas, devoluciones e inventario.
- Validación de stock antes de facturar.
- Cálculo automático de totales.
- Generación automática del detalle de venta.
- Protección de eliminaciones que podrían dejar referencias inconsistentes.
- Rollback compensatorio en operaciones que afectan más de una colección.

## Flujo integrado

### Compra → Inventario
Cuando una compra se registra como **Recibida**, el sistema:

1. guarda la compra;
2. aumenta el stock del producto;
3. registra una entrada en `inventario` vinculada a la compra.

### Venta → Detalle de venta → Inventario
Cuando se registra una venta, el sistema:

1. valida cliente, producto y método de pago;
2. verifica stock suficiente;
3. utiliza el precio vigente del producto;
4. calcula el total automáticamente;
5. guarda la venta;
6. genera el documento correspondiente en `detalleventas`;
7. descuenta el stock;
8. registra una salida en `inventario`.

### Devolución → Inventario
La devolución se genera a partir de una venta existente. El sistema valida la cantidad devuelta y vuelve a ingresar las unidades al inventario.

## Módulos

1. Clientes
2. Productos
3. Categorías
4. Proveedores
5. Compras
6. Ventas
7. Detalle de ventas
8. Inventario
9. Devoluciones
10. Métodos de pago
11. Sucursales
12. Usuarios

## Tecnologías utilizadas

- Node.js
- Express
- MongoDB
- Mongoose
- EJS
- Bootstrap 5
- Method Override
- JavaScript
- Postman

## Estructura del proyecto

```text
NovaTech/
├── controllers/       # Lógica de negocio
├── models/            # Esquemas Mongoose
├── routes/            # Rutas web y API
├── services/          # Servicios reutilizables de negocio
├── views/             # Interfaz EJS
├── public/            # CSS y recursos del frontend
├── scripts/           # Datos demo y verificaciones
├── postman/           # Colección de pruebas API
├── docs/              # Documentación técnica
├── app.js
└── package.json
```

## Instalación

```bash
npm install
npm run dev
```

La aplicación utiliza por defecto:

```text
mongodb://127.0.0.1:27017/NovaTechDB
```

Si se desea una conexión distinta, copie `.env.example` a `.env` y modifique `MONGODB_URI`.

## Datos de demostración

Para cargar catálogos y transacciones de demostración sin borrar información existente:

```bash
npm run seed
```

Después abra:

```text
http://localhost:3000
```

## Verificación del proyecto

Revisión estática de sintaxis, vistas e imports:

```bash
npm run check
```

Verificación de integridad entre colecciones y stock, con MongoDB activo:

```bash
npm run verify
```

## API para Postman

| Recurso | GET | POST |
|---|---|---|
| Estado del sistema | `/api/status` | — |
| Clientes | `/api/clientes` | `/api/clientes` |
| Categorías | `/api/categorias` | `/api/categorias` |
| Productos | `/api/productos` | `/api/productos` |
| Compras | `/api/compras` | `/api/compras` |
| Ventas | `/api/ventas` | `/api/ventas` |
| Detalle de ventas | `/api/detalle-ventas` | — |
| Inventario | `/api/inventario` | `/api/inventario` |
| Métodos de pago | `/api/metodos-pago` | `/api/metodos-pago` |

Los `POST` de compras, ventas e inventario respetan las reglas de stock del sistema.

## Diseño NoSQL

Las transacciones conservan referencias `ObjectId` hacia documentos principales y, al mismo tiempo, snapshots de datos relevantes como nombre del cliente, producto, proveedor o método de pago. Esto facilita las consultas históricas y demuestra una estrategia de **desnormalización controlada** propia de bases orientadas a documentos.

## Documentación

- `docs/ARQUITECTURA.md`: arquitectura, relaciones y reglas de negocio.
- `docs/MODELO_NOSQL.md`: diseño documental, índices y decisiones de modelado.
- `docs/PRUEBAS.md`: casos de prueba funcionales para la entrega.
- `docs/GUIA_DEMO.md`: recorrido recomendado para demostrar el sistema.
- `docs/REVISION_TECNICA.md`: verificaciones técnicas realizadas.
- `postman/NovaTech.postman_collection.json`: colección importable en Postman.

## Equipo

- Náraly Monge Contreras
- Paola Calderón Espinoza
- Mariano Jimenez Salas
